# -*- coding: utf-8 -*-
"""Build the whole bank into one folder.

Every board, every subject, grades 1–8, in the layout SCHEMA.md describes.
Maths keeps its own generator because it is the only subject whose answers
are computed; everything else comes through qbcore, which is what makes an
option list fair whatever wrote the item.
"""
import json, os, shutil, sys
import random
import gen_math, gen_english, gen_facts, gen_cbse
from qbcore import write_file

BOARDS = ['CBSE', 'ICSE', 'UK_NATIONAL', 'US_COMMON_CORE']
GRADES = range(1, 9)
FACT_SUBJECTS = ['Science', 'Social Studies', 'Computer Science', 'General Knowledge']

NOTE = {
 'Math': 'Generated from parameterised templates; every answer is computed from '
         'the same numbers the question is printed from, and re-derived '
         'independently by check_bank.py. Nothing is copied from any past paper '
         'or textbook.',
 'English': 'Built from spelling and grammar rules and from curated word lists. '
            'Rule-based answers are derived, not remembered. Nothing is copied '
            'from any past paper or textbook.',
 'other':  'Written for this bank from curated facts. Every question is marked '
           'review: pending until a person has read it. Nothing is copied from '
           'any past paper or textbook.',
}


def main(root='QUESTION_BANK', per=50, fresh=True):
    if fresh and os.path.isdir(root):
        shutil.rmtree(root)

    rows, totals = [], {}

    def record(board, subject, grade, qs, note):
        write_file(root, board, subject, grade, qs, note)
        rows.append((board, subject, grade, len(qs)))
        totals[subject] = totals.get(subject, 0) + len(qs)

    # ── CBSE, against the syllabus it actually has ──────────────────
    # Classes 1-5 study EVS, not Science. Hindi is core throughout.
    # Computational Thinking & AI runs from Class 3. Art, Physical Education
    # and Kaushal Bodh are in the syllabus and deliberately not here: they
    # are assessed by doing them, and a multiple-choice bank for those would
    # be trivia wearing the subject's name.
    for grade in GRADES:
        for subject in gen_cbse.subjects_for(grade):
            if subject == 'Mathematics':
                record('CBSE', subject, grade,
                       gen_math.build_file('CBSE', grade, per), NOTE['Math'])
            elif subject == 'English':
                record('CBSE', subject, grade,
                       gen_english.build_file('CBSE', grade, per), NOTE['English'])
            else:
                rnd = random.Random(f'CBSE|{subject}|{grade}')
                record('CBSE', subject, grade,
                       gen_cbse.build_subject(subject, grade, rnd), NOTE['other'])

    for board in [b for b in BOARDS if b != 'CBSE']:
        for grade in GRADES:
            record(board, 'Math', grade, gen_math.build_file(board, grade, per), NOTE['Math'])
            record(board, 'English', grade, gen_english.build_file(board, grade, per), NOTE['English'])
            for subj in FACT_SUBJECTS:
                record(board, subj, grade, gen_facts.build_file(board, subj, grade, per), NOTE['other'])

    # An index at the root, so anything reading the bank can see what is in
    # it without opening ninety-six files.
    index = {'boards': BOARDS, 'grades': list(GRADES),
             'subjects': sorted({r[1] for r in rows}),
             'cbse_subjects_by_grade': {g: gen_cbse.subjects_for(g) for g in GRADES},
             'not_included': ['Art Education', 'Physical Education', 'Kaushal Bodh'],
             'not_included_because':
                 'Assessed by doing rather than by choosing one of four.',
             'totals': totals, 'total': sum(totals.values()),
             'files': [{'board': b, 'subject': s, 'grade': g, 'count': n}
                       for b, s, g, n in rows]}
    with open(os.path.join(root, 'INDEX.JSON'), 'w', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, indent=1)

    print(f'{len(rows)} files, {sum(totals.values())} questions')
    for s, n in sorted(totals.items(), key=lambda kv: -kv[1]):
        print(f'  {s:<20} {n:>6}')
    # Where a subject could not honestly fill a file, say so here rather
    # than letting a round number imply it did.
    short = [(b, s, g, n) for b, s, g, n in rows if n < per * 3]
    if short:
        print(f'\n{len(short)} file(s) came up short of {per*3}; the curated '
              f'content for those does not stretch further yet:')
        by_subject = {}
        for b, s, g, n in short: by_subject.setdefault(s, []).append(n)
        for s, ns in by_subject.items():
            print(f'  {s:<20} {len(ns)} file(s), {min(ns)}–{max(ns)} questions each')
    return index


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'QUESTION_BANK')
