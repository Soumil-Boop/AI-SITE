# -*- coding: utf-8 -*-
"""CBSE, rebuilt against the actual syllabus rather than my guess at it.

Four things changed when the real syllabus arrived, and none of them was a
topic list — they were structural.

Classes 1–5 do not study Science. They study Environmental Studies, which
is a different subject with a different shape: myself, my family, the water
we drink, the people around us. Filing infant science under "Science" was
not a rounding error, it was the wrong subject.

Hindi did not exist in the bank at all, and it is a core subject in every
one of these eight classes.

Computational Thinking & AI runs from Class 3, and Social Science in 6–8 is
three strands — History, Geography, Civics — not one.

Art, Physical Education and Kaushal Bodh are in the syllabus and are
deliberately not in here. Drawing, fitness and project work are assessed by
doing them. A multiple-choice bank for those would be trivia about art and
sport wearing the subject's name, which is worse than an honest gap.
"""
import random
from qbcore import make
import cbse_extra as X

# ════════════════════════════════════════════════════════════════════
#  Which subjects a CBSE class actually has
# ════════════════════════════════════════════════════════════════════
def subjects_for(grade):
    core = ['English', 'Hindi', 'Mathematics']
    if grade <= 5:
        core.append('EVS')
    else:
        core += ['Science', 'Social Science']
    if grade >= 3:
        core.append('CT and AI')          # CBSE framework, Classes III–VIII
    return core


# ════════════════════════════════════════════════════════════════════
#  हिन्दी — Hindi
# ════════════════════════════════════════════════════════════════════
SWAR = ['अ', 'आ', 'इ', 'ई', 'उ', 'ऊ', 'ऋ', 'ए', 'ऐ', 'ओ', 'औ']
VYANJAN = ['क', 'ख', 'ग', 'घ', 'च', 'छ', 'ज', 'झ', 'ट', 'ठ', 'ड', 'ढ',
           'त', 'थ', 'द', 'ध', 'न', 'प', 'फ', 'ब', 'भ', 'म', 'य', 'र',
           'ल', 'व', 'श', 'ष', 'स', 'ह']

# शब्द : (शब्द, वचन-रूप, लिंग)
VACHAN = [('लड़का', 'लड़के'), ('लड़की', 'लड़कियाँ'), ('किताब', 'किताबें'),
          ('बच्चा', 'बच्चे'), ('नदी', 'नदियाँ'), ('कमरा', 'कमरे'),
          ('तितली', 'तितलियाँ'), ('पुस्तक', 'पुस्तकें'), ('घोड़ा', 'घोड़े'),
          ('चिड़िया', 'चिड़ियाँ'), ('सड़क', 'सड़कें'), ('बेटा', 'बेटे'),
          ('रात', 'रातें'), ('कहानी', 'कहानियाँ'), ('गाय', 'गायें')]

LING = [('लड़का', 'पुल्लिंग'), ('लड़की', 'स्त्रीलिंग'), ('पिता', 'पुल्लिंग'),
        ('माता', 'स्त्रीलिंग'), ('राजा', 'पुल्लिंग'), ('रानी', 'स्त्रीलिंग'),
        ('घोड़ा', 'पुल्लिंग'), ('घोड़ी', 'स्त्रीलिंग'), ('भाई', 'पुल्लिंग'),
        ('बहन', 'स्त्रीलिंग'), ('मोर', 'पुल्लिंग'), ('मोरनी', 'स्त्रीलिंग')]

VILOM = [('दिन', 'रात'), ('अच्छा', 'बुरा'), ('सुख', 'दुख'), ('ऊपर', 'नीचे'),
         ('आना', 'जाना'), ('छोटा', 'बड़ा'), ('सच', 'झूठ'), ('अमीर', 'गरीब'),
         ('मीठा', 'कड़वा'), ('नया', 'पुराना'), ('जीत', 'हार'), ('हँसना', 'रोना'),
         ('सुबह', 'शाम'), ('ठंडा', 'गरम'), ('आगे', 'पीछे'), ('प्रश्न', 'उत्तर')]

PARYAY = [('सूरज', 'सूर्य'), ('पानी', 'जल'), ('आँख', 'नेत्र'), ('फूल', 'पुष्प'),
          ('घर', 'गृह'), ('रात', 'निशा'), ('हवा', 'वायु'), ('पेड़', 'वृक्ष'),
          ('माता', 'जननी'), ('राजा', 'नृप'), ('पृथ्वी', 'धरती'), ('आग', 'अग्नि')]

SHABD_BHED = [('राम', 'संज्ञा'), ('मैं', 'सर्वनाम'), ('दौड़ना', 'क्रिया'),
              ('सुंदर', 'विशेषण'), ('दिल्ली', 'संज्ञा'), ('वह', 'सर्वनाम'),
              ('खाना', 'क्रिया'), ('लाल', 'विशेषण'), ('किताब', 'संज्ञा'),
              ('हम', 'सर्वनाम'), ('लिखना', 'क्रिया'), ('बड़ा', 'विशेषण')]

MUHAVARE = [('नौ दो ग्यारह होना', 'भाग जाना',
             ['बहुत खुश होना', 'गिनती करना', 'देर से आना']),
            ('आँखों का तारा', 'बहुत प्यारा',
             ['आँख का रोग', 'चमकता तारा', 'दूर की चीज़']),
            ('अपना उल्लू सीधा करना', 'अपना काम निकालना',
             ['पक्षी पालना', 'सीधा चलना', 'रात में जागना']),
            ('कान भरना', 'चुगली करना',
             ['कान साफ़ करना', 'ज़ोर से सुनना', 'बात न सुनना']),
            ('हाथ बँटाना', 'मदद करना',
             ['हाथ धोना', 'हिस्सा माँगना', 'लड़ाई करना']),
            ('चार चाँद लगाना', 'शोभा बढ़ाना',
             ['रात में देखना', 'चार दीये जलाना', 'देर करना'])]

MATRA = [('कि', 'इ'), ('की', 'ई'), ('कु', 'उ'), ('कू', 'ऊ'), ('के', 'ए'),
         ('कै', 'ऐ'), ('को', 'ओ'), ('कौ', 'औ'), ('का', 'आ')]

GINTI = [('१', 'एक'), ('२', 'दो'), ('३', 'तीन'), ('४', 'चार'), ('५', 'पाँच'),
         ('६', 'छह'), ('७', 'सात'), ('८', 'आठ'), ('९', 'नौ'), ('१०', 'दस')]


def hindi_questions(grade, rnd):
    out = []
    B = 'CBSE'; S = 'Hindi'

    def add(diff, topic, q, a, w, hint, expl):
        item = make(B, S, grade, diff, topic, q, a, w, hint, expl, rnd=rnd)
        if item: out.append(item)

    if grade <= 3:
        for ch in SWAR:
            add('easy', 'स्वर और व्यंजन', f'"{ch}" क्या है?', 'स्वर',
                ['व्यंजन', 'मात्रा', 'अंक'],
                'अ से अः तक स्वर होते हैं।', f'"{ch}" एक स्वर है।')
        for ch in VYANJAN[:16]:
            add('easy', 'स्वर और व्यंजन', f'"{ch}" क्या है?', 'व्यंजन',
                ['स्वर', 'मात्रा', 'अंक'],
                'क से ह तक व्यंजन होते हैं।', f'"{ch}" एक व्यंजन है।')
        for sym, name in GINTI:
            add('medium', 'गिनती', f'"{sym}" को शब्दों में कैसे लिखेंगे?', name,
                [x for _, x in GINTI if x != name][:3],
                'हिंदी की गिनती याद कीजिए।', f'{sym} को "{name}" लिखते हैं।')
        for w, m in MATRA:
            # मात्रा recognition is the hardest thing in the first three
            # classes; without this the file has no hard band at all.
            add('hard', 'मात्राएँ', f'"{w}" में कौन-सी मात्रा है?', m,
                [x for _, x in MATRA if x != m][:3],
                'अक्षर के साथ लगी मात्रा देखिए।', f'"{w}" में "{m}" की मात्रा है।')

    if grade >= 2:
        for ek, bahu in VACHAN:
            add('easy' if grade <= 3 else 'easy', 'वचन',
                f'"{ek}" का बहुवचन क्या है?', bahu,
                [x for _, x in VACHAN if x != bahu][:3],
                'एक से अधिक के लिए रूप बदलता है।',
                f'"{ek}" का बहुवचन "{bahu}" है।')
        for w, g in LING:
            add('medium', 'लिंग', f'"{w}" शब्द का लिंग क्या है?', g,
                ['स्त्रीलिंग' if g == 'पुल्लिंग' else 'पुल्लिंग', 'नपुंसकलिंग', 'बहुवचन'],
                'पुरुष के लिए पुल्लिंग, स्त्री के लिए स्त्रीलिंग।',
                f'"{w}" {g} है।')

    if grade >= 3:
        for a, b in VILOM:
            add('medium', 'विलोम शब्द', f'"{a}" का विलोम शब्द क्या है?', b,
                [y for x, y in VILOM if y != b][:3],
                'उल्टा अर्थ वाला शब्द चुनिए।', f'"{a}" का विलोम "{b}" है।')
        for w, t in SHABD_BHED:
            add('medium', 'शब्द भेद', f'"{w}" शब्द किस भेद का है?', t,
                [x for x in ['संज्ञा', 'सर्वनाम', 'क्रिया', 'विशेषण'] if x != t][:3],
                'नाम, नाम के बदले, काम या विशेषता — देखिए।',
                f'"{w}" {t} है।')

    if grade >= 4:
        for a, b in PARYAY:
            add('hard', 'पर्यायवाची', f'"{a}" का पर्यायवाची शब्द क्या है?', b,
                [y for x, y in PARYAY if y != b][:3],
                'समान अर्थ वाला शब्द चुनिए।', f'"{a}" का पर्यायवाची "{b}" है।')

    if grade >= 5:
        for m, arth, w in MUHAVARE:
            add('hard', 'मुहावरे', f'"{m}" मुहावरे का अर्थ क्या है?', arth, list(w),
                'मुहावरे का अर्थ शब्दों से अलग होता है।',
                f'"{m}" का अर्थ है — {arth}।')
    return out


# ════════════════════════════════════════════════════════════════════
#  EVS — Environmental Studies, Classes 1–5
# ════════════════════════════════════════════════════════════════════
EVS = {
 'low': [   # classes 1–2
  ('Which part of your body do you use to see?', 'the eyes',
   ['the ears', 'the nose', 'the tongue'], 'sense organs'),
  ('Which part of your body do you use to hear?', 'the ears',
   ['the eyes', 'the skin', 'the tongue'], 'sense organs'),
  ('How many sense organs does a human being have?', 'five',
   ['three', 'four', 'six'], 'sense organs'),
  ('Who takes care of you at home?', 'my family',
   ['the postman', 'the shopkeeper', 'strangers'], 'family'),
  ('Which of these do we need every day to stay alive?', 'water',
   ['a toy', 'a television', 'a bicycle'], 'water'),
  ('Where does the water we drink at home usually come from?', 'a tap or a well',
   ['a cupboard', 'a bookshelf', 'the roof'], 'water'),
  ('Why should we wash our hands before eating?', 'to remove germs',
   ['to make them cold', 'to make them wet', 'to make them soft'], 'cleanliness'),
  ('Which of these keeps us warm in winter?', 'a woollen sweater',
   ['a cotton vest', 'a raincoat', 'a swimming costume'], 'clothes'),
  ('Which of these is a means of transport?', 'a bus',
   ['a chair', 'a plate', 'a pillow'], 'transport'),
  ('Who helps us when we are ill?', 'a doctor',
   ['a driver', 'a farmer', 'a painter'], 'people around us'),
  ('Who brings letters to our home?', 'the postman',
   ['the teacher', 'the doctor', 'the plumber'], 'people around us'),
  ('When do we see the Sun in the sky?', 'during the day',
   ['at night', 'only in winter', 'only at midnight'], 'day and night'),
  ('What do we call the season when it is very hot?', 'summer',
   ['winter', 'the rainy season', 'autumn'], 'weather'),
  ('Which of these animals lives in water?', 'a fish',
   ['a cow', 'a hen', 'a goat'], 'animals'),
  ('Which part of a plant is usually under the ground?', 'the root',
   ['the leaf', 'the flower', 'the fruit'], 'plants'),
  ('What should you do before crossing a road?', 'look on both sides',
   ['run quickly', 'close your eyes', 'shout loudly'], 'safety'),
  ('Which of these is a healthy food?', 'fruit',
   ['a fizzy drink', 'a packet of sweets', 'crisps'], 'food'),
  ('What kind of house is made of bricks and cement?', 'a pucca house',
   ['a tent', 'a hut of straw', 'a houseboat'], 'houses'),
 ],
 'mid': [   # classes 3–5
  ('Which organ of the body pumps blood?', 'the heart',
   ['the lungs', 'the stomach', 'the brain'], 'human body'),
  ('Which organ helps us to breathe?', 'the lungs',
   ['the heart', 'the liver', 'the kidney'], 'human body'),
  ('Where does digestion of food begin?', 'in the mouth',
   ['in the stomach', 'in the intestine', 'in the liver'], 'food and health'),
  ('Which nutrient gives us the most energy?', 'carbohydrates',
   ['vitamins', 'minerals', 'water'], 'food and health'),
  ('Which food group helps the body to grow and repair?', 'proteins',
   ['fats', 'carbohydrates', 'water'], 'food and health'),
  ('Which vitamin do we get from sunlight?', 'vitamin D',
   ['vitamin A', 'vitamin C', 'vitamin K'], 'food and health'),
  ('What is the process of water changing into vapour called?', 'evaporation',
   ['condensation', 'filtration', 'irrigation'], 'water'),
  ('Which of these is a way of saving water at home?', 'closing the tap while brushing',
   ['leaving the tap running', 'washing the car daily', 'filling the bath twice'], 'conservation'),
  ('Where do plants make their food?', 'in the leaves',
   ['in the roots', 'in the stem', 'in the soil'], 'plants'),
  ('Which animals give us milk?', 'cows and buffaloes',
   ['hens and ducks', 'fish and crabs', 'snakes and lizards'], 'animals'),
  ('What is the home of a bird called?', 'a nest',
   ['a burrow', 'a stable', 'a kennel'], 'animals'),
  ('Which of these is a natural source of water?', 'a river',
   ['a tap', 'a bucket', 'a bottle'], 'water'),
  ('Which gas do we breathe out?', 'carbon dioxide',
   ['oxygen', 'nitrogen', 'hydrogen'], 'air'),
  ('Which of these materials can be recycled?', 'paper',
   ['a banana peel', 'cooked rice', 'a dry leaf'], 'environment'),
  ('What do we call animals that eat only plants?', 'herbivores',
   ['carnivores', 'omnivores', 'predators'], 'animals'),
  ('Which direction does the Sun rise from?', 'the east',
   ['the west', 'the north', 'the south'], 'environment'),
  ('What is a map used for?', 'to show places and directions',
   ['to tell the time', 'to measure weight', 'to cook food'], 'travel'),
  ('Which of these is a means of communication?', 'a telephone',
   ['a bicycle', 'a spoon', 'a shoe'], 'people around us'),
  ('Why do we need shelter?', 'to protect us from weather and danger',
   ['to look rich', 'to store money', 'to grow plants'], 'shelter'),
  ('Which of these is a natural resource?', 'coal',
   ['plastic', 'glass bottles', 'paper bags'], 'natural resources'),
 ],
}

# ════════════════════════════════════════════════════════════════════
#  Computational Thinking & AI, Classes 3–8
#  On-theme for this site, and the one place where "what AI cannot do"
#  belongs as much as "what it can".
# ════════════════════════════════════════════════════════════════════
CTAI = {
 'low': [   # classes 3–5
  ('What is an algorithm?', 'a step-by-step set of instructions',
   ['a kind of computer', 'a picture', 'a number'], 'algorithms'),
  ('What comes next in the pattern: circle, square, circle, square, ?', 'circle',
   ['square', 'triangle', 'nothing'], 'patterns'),
  ('Putting steps in the right order is called', 'sequencing',
   ['guessing', 'counting', 'drawing'], 'sequencing'),
  ('Breaking a big problem into smaller parts is called', 'decomposition',
   ['repetition', 'guessing', 'collection'], 'problem solving'),
  ('Which of these is a set of instructions a computer can follow?', 'a program',
   ['a poster', 'a song', 'a photograph'], 'algorithms'),
  ('If a robot must make tea, which step comes first?', 'boil the water',
   ['pour the tea', 'drink the tea', 'wash the cup afterwards'], 'sequencing'),
  ('What should you do if a website asks for your home address?', 'ask an adult first',
   ['type it quickly', 'share it with everyone', 'guess an address'], 'digital awareness'),
  ('Which of these is an example of a pattern?', '2, 4, 6, 8',
   ['7, 1, 9, 3', 'a, z, m, k', '5, 5, 2, 9'], 'patterns'),
  ('What does a computer need before it can answer a question?', 'instructions and data',
   ['a good mood', 'a name', 'a colour'], 'data'),
  ('Doing the same step again and again in a program is called', 'repetition',
   ['decomposition', 'sequencing', 'debugging'], 'algorithms'),
 ],
 'mid': [   # classes 6–8
  ('What does AI stand for?', 'Artificial Intelligence',
   ['Automatic Input', 'Advanced Internet', 'Applied Information'], 'AI concepts'),
  ('How does a machine learning model mainly learn?', 'from examples in data',
   ['from rules typed in by hand', 'from guessing randomly', 'from the internet speed'],
   'AI concepts'),
  ('What is training data?', 'the examples a model learns from',
   ['the answer a model gives', 'the speed of a computer', 'a type of program'], 'data'),
  ('If a face recognition system is trained mostly on one group of people, it is likely to',
   'work less well for other groups',
   ['work equally well for everyone', 'stop working completely', 'become faster'],
   'responsible technology'),
  ('What is bias in an AI system?', 'unfairness that comes from the data or the design',
   ['a hardware fault', 'a slow internet connection', 'a spelling mistake'],
   'responsible technology'),
  ('Which of these is a good reason to check what an AI tells you?',
   'it can state wrong things confidently',
   ['it is always right', 'it is never used', 'it cannot write'], 'responsible technology'),
  ('What is a mistake in a program called?', 'a bug',
   ['a virus', 'a driver', 'a folder'], 'problem solving'),
  ('Finding and fixing mistakes in a program is called', 'debugging',
   ['decomposing', 'compiling', 'formatting'], 'problem solving'),
  ('Which of these tasks is a computer better at than a person?',
   'adding a million numbers quickly',
   ['understanding a friend\'s feelings', 'deciding what is fair', 'enjoying a poem'],
   'AI concepts'),
  ('Which of these is personal data?', 'your home address',
   ['the colour of the sky', 'the name of your country', 'the number of days in a week'],
   'digital awareness'),
  ('An algorithm that always gives the same output for the same input is called',
   'deterministic', ['random', 'biased', 'recursive'], 'algorithms'),
  ('What is the first step of computational thinking when facing a big problem?',
   'break it into smaller parts',
   ['write the final answer', 'buy a faster computer', 'ask someone else'], 'problem solving'),
  ('A chatbot that writes a paragraph is an example of', 'generative AI',
   ['a spreadsheet', 'an operating system', 'a printer driver'], 'AI concepts'),
  ('Why should you not share a password with a friend?',
   'they could use your account without you knowing',
   ['it is too long to type', 'it will be forgotten', 'it slows the computer'],
   'digital awareness'),
  ('What does it mean to give credit when you use an AI tool for schoolwork?',
   'say clearly where the help came from',
   ['keep it secret', 'change a few words', 'copy it exactly'], 'responsible technology'),
 ],
}

# ════════════════════════════════════════════════════════════════════
#  Science, Classes 6–8 — the chapters the syllabus actually names
# ════════════════════════════════════════════════════════════════════
SCIENCE_CBSE = {
 6: [
  ('Which nutrient is present in large amounts in rice and bread?', 'carbohydrates',
   ['proteins', 'fats', 'vitamins'], 'components of food'),
  ('A deficiency of vitamin C causes which disease?', 'scurvy',
   ['rickets', 'goitre', 'night blindness'], 'components of food'),
  ('Which method separates lighter husk from heavier grain using wind?', 'winnowing',
   ['sieving', 'filtration', 'threshing'], 'separation of substances'),
  ('Which method would you use to separate sand from water?', 'filtration',
   ['winnowing', 'evaporation', 'churning'], 'separation of substances'),
  ('The change of ice into water is which kind of change?', 'a reversible change',
   ['an irreversible change', 'a chemical change', 'a permanent change'], 'changes around us'),
  ('Which of these joints allows movement in all directions?', 'the ball and socket joint',
   ['the hinge joint', 'the fixed joint', 'the pivot joint'], 'body movements'),
  ('Which part of the plant holds it firmly in the soil?', 'the root',
   ['the leaf', 'the flower', 'the fruit'], 'getting to know plants'),
  ('The SI unit of length is', 'the metre',
   ['the kilogram', 'the second', 'the litre'], 'motion and measurement'),
  ('An object through which we cannot see at all is called', 'opaque',
   ['transparent', 'translucent', 'luminous'], 'light'),
  ('An electric circuit is complete only when it is', 'closed',
   ['open', 'broken', 'switched off'], 'electricity'),
  ('The needle of a compass always points towards', 'north',
   ['east', 'west', 'south'], 'magnets'),
  ('Which of these is a way of harvesting rainwater?', 'collecting roof water in a tank',
   ['leaving taps running', 'draining water into the road', 'boiling water'], 'water'),
  ('Which gas in air is used by plants to make food?', 'carbon dioxide',
   ['oxygen', 'nitrogen', 'argon'], 'air'),
  ('Waste that rots naturally is called', 'biodegradable',
   ['non-biodegradable', 'recyclable', 'synthetic'], 'garbage and environment'),
 ],
 7: [
  ('The mode of nutrition in green plants is', 'autotrophic',
   ['heterotrophic', 'parasitic', 'saprophytic'], 'nutrition (biology)'),
  ('Which organ produces bile in the human body?', 'the liver',
   ['the stomach', 'the pancreas', 'the kidney'], 'nutrition (biology)'),
  ('Which of these is anaerobic respiration in humans?',
   'the formation of lactic acid in muscles',
   ['breathing through the nose', 'exchange of gases in the lungs',
    'the beating of the heart'], 'respiration (biology)'),
  ('Which tissue carries water from the roots to the leaves?', 'xylem',
   ['phloem', 'cambium', 'epidermis'], 'transportation (biology)'),
  ('The transfer of pollen from anther to stigma is called', 'pollination',
   ['fertilisation', 'germination', 'respiration'], 'reproduction in plants'),
  ('Heat travels through a metal rod mainly by', 'conduction',
   ['convection', 'radiation', 'evaporation'], 'heat (physics)'),
  ('Which instrument measures body temperature?', 'a clinical thermometer',
   ['a barometer', 'an ammeter', 'a hygrometer'], 'heat (physics)'),
  ('Which of these turns blue litmus red?', 'an acid',
   ['a base', 'a neutral solution', 'distilled water'], 'acids and bases (chemistry)'),
  ('Rusting of iron is which kind of change?', 'a chemical change',
   ['a physical change', 'a reversible change', 'a temporary change'],
   'physical and chemical changes'),
  ('The layer of soil richest in humus is', 'the topsoil',
   ['the subsoil', 'the bedrock', 'the C horizon'], 'soil (chemistry)'),
  ('The heating effect of electric current is used in', 'an electric heater',
   ['a compass', 'a mirror', 'a lens'], 'electric current (physics)'),
  ('An image formed by a plane mirror is', 'virtual and the same size',
   ['real and inverted', 'real and smaller', 'virtual and larger'], 'light (physics)'),
  ('Sound cannot travel through', 'a vacuum',
   ['air', 'water', 'steel'], 'sound (physics)'),
  ('Which of these is a windy, rainy weather condition of the tropics?', 'a cyclone',
   ['a drought', 'a snowfall', 'a heatwave'], 'weather and climate'),
 ],
 8: [
  ('The process of loosening and turning soil before sowing is called', 'ploughing',
   ['sowing', 'harvesting', 'threshing'], 'crop production'),
  ('Which micro-organism is used to make curd from milk?', 'bacteria',
   ['a virus', 'an alga', 'a protozoan'], 'microorganisms'),
  ('Which of these is a synthetic fibre?', 'nylon',
   ['cotton', 'jute', 'wool'], 'materials (chemistry)'),
  ('Which of these is a non-metal that conducts electricity?', 'graphite',
   ['sulphur', 'phosphorus', 'iodine'], 'metals and non-metals'),
  ('Coal and petroleum are called fossil fuels because they were formed from',
   'the remains of living organisms',
   ['volcanic rock', 'sea salt', 'desert sand'], 'coal and petroleum'),
  ('The lowest temperature at which a substance catches fire is its', 'ignition temperature',
   ['melting point', 'boiling point', 'freezing point'], 'combustion'),
  ('Force per unit area is called', 'pressure',
   ['friction', 'momentum', 'work'], 'force and pressure (physics)'),
  ('Friction can be reduced by', 'using lubricants',
   ['making surfaces rougher', 'increasing the weight', 'removing the wheels'],
   'friction (physics)'),
  ('The number of vibrations per second is called', 'frequency',
   ['amplitude', 'wavelength', 'pitch'], 'sound (physics)'),
  ('Passing electric current through a liquid can cause', 'a chemical change',
   ['no change at all', 'only a rise in volume', 'only a change of colour'],
   'chemical effects of electric current'),
  ('The building block of all living things is', 'the cell',
   ['the atom', 'the molecule', 'the tissue'], 'cells'),
  ('In which type of reproduction is only one parent needed?', 'asexual reproduction',
   ['sexual reproduction', 'binary reproduction only', 'external fertilisation'],
   'reproduction (biology)'),
  ('The period of life when the body matures towards adulthood is called', 'adolescence',
   ['infancy', 'old age', 'childhood'], 'adolescence'),
  ('Which of these helps conserve wildlife?', 'a national park',
   ['a coal mine', 'a shopping centre', 'a highway'], 'conservation'),
 ],
}

# ════════════════════════════════════════════════════════════════════
#  Social Science, Classes 6–8 — three strands, as the syllabus has it
# ════════════════════════════════════════════════════════════════════
SOCSCI_CBSE = {
 6: [
  ('The earliest people in India were mainly', 'hunter-gatherers',
   ['farmers', 'traders', 'kings'], 'History: early humans'),
  ('Which of these is a source used by historians to study the past?', 'inscriptions',
   ['weather reports', 'today\'s newspapers only', 'shopping lists'], 'History: sources'),
  ('Harappan cities are known for their', 'careful town planning and drainage',
   ['tall stone temples', 'iron weapons', 'paper records'], 'History: early civilizations'),
  ('The imaginary line that divides the Earth into two equal halves is', 'the Equator',
   ['the Tropic of Cancer', 'the Prime Meridian', 'the Arctic Circle'], 'Geography: globes'),
  ('Which is the largest continent by area?', 'Asia',
   ['Africa', 'Europe', 'Antarctica'], 'Geography: continents'),
  ('A model of the Earth is called', 'a globe',
   ['a map', 'an atlas', 'a chart'], 'Geography: globes'),
  ('Which landform is a large area of flat, high land?', 'a plateau',
   ['a plain', 'a mountain', 'a valley'], 'Geography: landforms'),
  ('The smallest unit of rural local government in India is', 'the Gram Panchayat',
   ['the Lok Sabha', 'the Municipal Corporation', 'the State Assembly'],
   'Civics: local government'),
  ('The variety of people, languages and customs in a country is called', 'diversity',
   ['equality', 'poverty', 'literacy'], 'Civics: diversity'),
 ],
 7: [
  ('The Delhi Sultanate was ruled from', 'Delhi',
   ['Vijayanagara', 'Golconda', 'Madurai'], 'History: Delhi Sultanate'),
  ('Who was the founder of the Mughal Empire in India?', 'Babur',
   ['Akbar', 'Sher Shah Suri', 'Aurangzeb'], 'History: Mughals'),
  ('Akbar\'s policy of religious tolerance was known as', 'sulh-i-kul',
   ['jizya', 'iqta', 'mansab'], 'History: Mughals'),
  ('The removal of the top layer of soil by wind or water is called', 'soil erosion',
   ['irrigation', 'sedimentation', 'weathering only'], 'Geography: earth processes'),
  ('Which layer of the atmosphere do we live in?', 'the troposphere',
   ['the stratosphere', 'the mesosphere', 'the exosphere'], 'Geography: air'),
  ('The movement of ocean water rising and falling twice a day is called', 'tides',
   ['waves', 'currents', 'monsoons'], 'Geography: water'),
  ('In India, law and order within a state is mainly the responsibility of',
   'the state government',
   ['the central government', 'the village panchayat', 'the Supreme Court alone'],
   'Civics: state government'),
  ('A market where goods are sold directly to the customer is called', 'a retail market',
   ['a wholesale market', 'a stock market', 'a labour market'], 'Civics: markets'),
  ('Treating everyone the same regardless of caste, religion or gender is called',
   'equality', ['liberty', 'sovereignty', 'federalism'], 'Civics: equality'),
 ],
 8: [
  ('The East India Company won the Battle of Plassey in', '1757',
   ['1857', '1947', '1600'], 'History: East India Company'),
  ('The Revolt of 1857 began at', 'Meerut',
   ['Calcutta', 'Madras', 'Bombay'], 'History: Revolt of 1857'),
  ('Raja Ram Mohan Roy is best known for campaigning against', 'sati',
   ['the salt tax', 'the partition of Bengal', 'the Rowlatt Act'], 'History: social reform'),
  ('The Indian National Congress was founded in', '1885',
   ['1857', '1905', '1947'], 'History: national movement'),
  ('Resources that will run out if used carelessly are called', 'non-renewable resources',
   ['renewable resources', 'human resources', 'flow resources'], 'Geography: resources'),
  ('Growing crops mainly to sell rather than to eat is called', 'commercial farming',
   ['subsistence farming', 'shifting cultivation', 'organic farming only'],
   'Geography: agriculture'),
  ('An industry that makes goods from raw materials is called', 'a manufacturing industry',
   ['a primary industry', 'a service industry', 'a tertiary industry'],
   'Geography: industries'),
  ('The Constitution of India came into force on', '26 January 1950',
   ['15 August 1947', '26 November 1949', '2 October 1950'], 'Civics: Constitution'),
  ('The highest court in India is', 'the Supreme Court',
   ['the High Court', 'the District Court', 'the Lok Adalat'], 'Civics: judiciary'),
  ('The Indian Parliament is made up of', 'the Lok Sabha and the Rajya Sabha',
   ['the Lok Sabha only', 'the Rajya Sabha only', 'the Cabinet and the President'],
   'Civics: Parliament'),
  ('Facilities such as water, electricity and healthcare that everyone should have are called',
   'public facilities',
   ['private goods', 'luxury items', 'exports'], 'Civics: public facilities'),
 ],
}


# ── The curated content lives in cbse_extra.py; merged here so that adding
#    to the bank means adding to a list rather than reading code. ──────
for _b in ('low', 'mid'):
    EVS[_b] += X.EVS_MORE[_b]
    CTAI[_b] += X.CTAI_MORE[_b]
for _g in (6, 7, 8):
    SCIENCE_CBSE[_g] += X.SCIENCE_MORE[_g]
    SOCSCI_CBSE[_g] += X.SOCSCI_MORE[_g]
VILOM += X.VILOM_MORE
PARYAY += X.PARYAY_MORE
VACHAN += X.VACHAN_MORE
LING += X.LING_MORE
MUHAVARE += X.MUHAVARE_MORE
SHABD_BHED += X.SHABD_BHED_MORE


def _facts_to_questions(items, subject, grade, rnd, difficulty_of):
    out = []
    for i, (q, a, w, topic) in enumerate(items):
        item = make('CBSE', subject, grade, difficulty_of(i, topic), topic, q, a, list(w),
                    'Think about what this chapter covered.',
                    f'The answer is {a}.', rnd=rnd)
        if item: out.append(item)
    return out


def build_subject(subject, grade, rnd):
    """One CBSE subject for one class, from the syllabus above."""
    if subject == 'Hindi':
        return hindi_questions(grade, rnd)

    if subject == 'EVS':
        out = []
        if grade <= 2:
            # One band available, so the three difficulties are spread across
            # it rather than left empty — a file with no easy questions is a
            # file a seven-year-old cannot start.
            out += _facts_to_questions(
                EVS['low'], 'EVS', grade, rnd,
                lambda i, t: ('easy', 'medium', 'hard')[i % 3])
        else:
            out += _facts_to_questions(EVS['low'], 'EVS', grade, rnd,
                                       lambda i, t: 'easy')
            out += _facts_to_questions(
                EVS['mid'], 'EVS', grade, rnd,
                lambda i, t: 'medium' if i % 2 else 'hard')
        return out

    if subject == 'CT and AI':
        band = 'low' if grade <= 5 else 'mid'
        items = CTAI['low'] + (CTAI['mid'] if grade >= 6 else [])
        return _facts_to_questions(
            items, 'CT and AI', grade, rnd,
            lambda i, t: 'easy' if i < 4 else ('medium' if i % 2 else 'hard'))

    if subject == 'Science':
        return _facts_to_questions(
            SCIENCE_CBSE.get(grade, []), 'Science', grade, rnd,
            lambda i, t: 'easy' if i < 4 else ('medium' if i % 2 else 'hard'))

    if subject == 'Social Science':
        return _facts_to_questions(
            SOCSCI_CBSE.get(grade, []), 'Social Science', grade, rnd,
            lambda i, t: 'easy' if i < 3 else ('medium' if i % 2 else 'hard'))

    return []
