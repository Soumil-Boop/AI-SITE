# -*- coding: utf-8 -*-
"""Science, Social Studies, Computer Science and General Knowledge.

None of these can be generated the way maths can. A science answer is only
as right as the fact behind it, so what is generated here is the *question*,
never the fact: every fact below was written down once, deliberately, and
the machinery only turns it into a fair four-option question.

Two consequences, both deliberate.

Files in these subjects come in smaller than the maths files. `fill` stops
when the curated content is exhausted rather than padding to a round number
with near-duplicates, so a count of 96 means ninety-six real questions and
not a hundred and fifty with fifty-four of them rephrased.

And every question here carries `review: pending`. Nothing in this file has
been read by a person other than its author, and the bank should say so
rather than let a generated-looking `source` field imply a guarantee it
cannot give.

Social Studies is board-specific on purpose. A child on the UK curriculum
is not studying the states of India, and averaging the two into a bland
world-geography quiz would serve neither.
"""
import random
from qbcore import make, fill

# ════════════════════════════════════════════════════════════════════
#  Grouped facts: "which of these is a …". The distractors come from the
#  sibling groups, so a wrong option is always a real thing of the wrong
#  kind — never a nonsense word, which is free to eliminate.
# ════════════════════════════════════════════════════════════════════
GROUPS = {
 'Science': {
  'low': {
   'mammal':       ['dog', 'cat', 'cow', 'whale', 'bat', 'elephant', 'horse', 'lion'],
   'bird':         ['crow', 'sparrow', 'eagle', 'penguin', 'owl', 'peacock', 'duck'],
   'reptile':      ['snake', 'lizard', 'crocodile', 'turtle', 'chameleon'],
   'insect':       ['ant', 'butterfly', 'bee', 'grasshopper', 'mosquito'],
   'fish':         ['shark', 'goldfish', 'salmon', 'tuna'],
   'fruit':        ['mango', 'apple', 'banana', 'orange', 'grape', 'pear'],
   'vegetable':    ['carrot', 'potato', 'onion', 'spinach', 'cabbage', 'pea'],
   'sense organ':  ['eye', 'ear', 'nose', 'tongue', 'skin'],
   'farm animal':  ['hen', 'buffalo', 'donkey', 'pig'],
   'wild animal':  ['tiger', 'giraffe', 'zebra', 'hyena', 'rhinoceros'],
   'flowering plant': ['rose', 'sunflower', 'jasmine', 'hibiscus', 'marigold'],
   'tree':         ['banyan', 'oak', 'neem', 'pine', 'teak'],
   'means of transport': ['bicycle', 'aeroplane', 'ferry', 'tram'],
   'body covering': ['fur', 'feathers', 'scales', 'shell'],
  },
  'mid': {
   'herbivore':    ['cow', 'goat', 'deer', 'rabbit', 'elephant'],
   'carnivore':    ['lion', 'tiger', 'wolf', 'eagle', 'shark'],
   'omnivore':     ['bear', 'crow', 'pig', 'human'],
   'solid':        ['ice', 'wood', 'iron', 'stone'],
   'liquid':       ['water', 'milk', 'oil', 'mercury'],
   'gas':          ['oxygen', 'nitrogen', 'steam', 'helium'],
   'source of light': ['the Sun', 'a candle', 'a torch', 'a firefly'],
   'planet':       ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn',
                    'Uranus', 'Neptune'],
   'natural resource': ['water', 'coal', 'sunlight', 'soil', 'wind'],
   'simple machine': ['lever', 'pulley', 'wedge', 'screw', 'inclined plane'],
   'source of sound': ['drum', 'whistle', 'guitar', 'bell'],
   'part of a flower': ['petal', 'sepal', 'stamen', 'pistil'],
   'aquatic animal': ['dolphin', 'octopus', 'starfish', 'seahorse'],
   'amphibian':    ['frog', 'toad', 'newt', 'salamander'],
   'weather condition': ['rain', 'fog', 'hail', 'snow', 'thunderstorm'],
   'measuring instrument': ['ruler', 'weighing balance', 'measuring jar', 'stopwatch'],
  },
  'high': {
   'conductor':    ['copper', 'aluminium', 'silver', 'iron'],
   'insulator':    ['rubber', 'glass', 'plastic', 'wood'],
   'renewable energy source': ['solar power', 'wind power', 'hydro power',
                               'tidal power', 'geothermal power'],
   'non-renewable energy source': ['coal', 'petroleum', 'natural gas'],
   'noble gas':    ['helium', 'neon', 'argon', 'krypton', 'xenon'],
   'metal':        ['iron', 'gold', 'zinc', 'magnesium', 'sodium'],
   'non-metal':    ['sulphur', 'carbon', 'phosphorus', 'iodine'],
   'organ of the digestive system': ['stomach', 'liver', 'small intestine',
                                     'pancreas', 'oesophagus'],
   'organ of the respiratory system': ['lungs', 'trachea', 'diaphragm', 'bronchi'],
   'organ of the circulatory system': ['heart', 'artery', 'vein', 'capillary'],
   'organ of the nervous system': ['brain', 'spinal cord', 'nerve'],
   'acid':         ['hydrochloric acid', 'sulphuric acid', 'citric acid', 'acetic acid'],
   'base':         ['sodium hydroxide', 'calcium hydroxide', 'ammonia'],
   'alloy':        ['brass', 'bronze', 'steel', 'solder'],
   'form of energy': ['heat', 'light', 'sound', 'electrical energy'],
   'unit of measurement': ['metre', 'kilogram', 'second', 'kelvin', 'mole'],
   'greenhouse gas': ['carbon dioxide', 'methane', 'water vapour', 'nitrous oxide'],
   'micro-organism': ['bacteria', 'virus', 'fungi', 'protozoa'],
  },
 },
 'Computer Science': {
  'low': {
   'input device':  ['keyboard', 'mouse', 'microphone', 'scanner', 'webcam'],
   'output device': ['monitor', 'printer', 'speaker', 'headphones', 'projector'],
   'storage device':['hard disk', 'pen drive', 'memory card', 'CD'],
   'part of a desktop computer': ['CPU cabinet', 'monitor', 'keyboard', 'mouse'],
  },
  'mid': {
   'operating system': ['Windows', 'Linux', 'macOS', 'Android'],
   'web browser':      ['Chrome', 'Firefox', 'Safari', 'Edge'],
   'input device':     ['keyboard', 'mouse', 'joystick', 'touchpad'],
   'output device':    ['monitor', 'printer', 'plotter', 'speaker'],
   'application software': ['word processor', 'spreadsheet', 'paint program',
                            'presentation software'],
   'type of file':     ['document', 'image', 'audio file', 'video file'],
  },
  'high': {
   'programming language': ['Python', 'Java', 'C++', 'JavaScript', 'Ruby'],
   'markup or style language': ['HTML', 'CSS', 'XML', 'Markdown'],
   'unit of computer memory': ['byte', 'kilobyte', 'megabyte', 'gigabyte', 'terabyte'],
   'network device': ['router', 'switch', 'modem', 'hub'],
   'type of network': ['LAN', 'WAN', 'MAN', 'PAN'],
   'cyber safety practice': ['using a strong password', 'logging out after use',
                             'keeping software updated', 'not sharing personal details'],
   'input/output port': ['USB port', 'HDMI port', 'ethernet port', 'audio jack'],
  },
 },
}

# ════════════════════════════════════════════════════════════════════
#  Direct facts. (question, answer, [three wrong], topic)
# ════════════════════════════════════════════════════════════════════
FACTS = {
 'Science': {
  'low': [
   ('How many legs does an insect have?', 'six', ['four', 'eight', 'ten'], 'animals'),
   ('How many legs does a spider have?', 'eight', ['six', 'four', 'ten'], 'animals'),
   ('Which part of a plant takes in water from the soil?', 'the roots',
    ['the leaves', 'the flower', 'the stem'], 'plants'),
   ('Which part of a plant makes food?', 'the leaves',
    ['the roots', 'the stem', 'the fruit'], 'plants'),
   ('What do we call the young one of a frog?', 'a tadpole',
    ['a cub', 'a calf', 'a chick'], 'animals'),
   ('Which sense organ do we use to smell?', 'the nose',
    ['the ear', 'the tongue', 'the eye'], 'human body'),
   ('How many teeth does an adult human usually have?', '32',
    ['20', '24', '28'], 'human body'),
   ('What gas do humans need to breathe in to stay alive?', 'oxygen',
    ['carbon dioxide', 'nitrogen', 'hydrogen'], 'human body'),
   ('Which animal is known as the ship of the desert?', 'the camel',
    ['the horse', 'the donkey', 'the elephant'], 'animals'),
   ('What is the main source of light on Earth during the day?', 'the Sun',
    ['the Moon', 'the stars', 'lightning'], 'our surroundings'),
   ('Water turns into ice when it is', 'cooled', ['heated', 'stirred', 'poured'], 'matter'),
   ('Which of these floats on water?', 'a wooden block',
    ['an iron nail', 'a stone', 'a coin'], 'matter'),
   ('How many days are there in a leap year?', '366', ['365', '364', '367'], 'earth and space'),
   ('Which season comes after summer?', 'autumn', ['spring', 'winter', 'monsoon'], 'earth and space'),
   ('What do plants give out during photosynthesis?', 'oxygen',
    ['carbon dioxide', 'nitrogen', 'water vapour'], 'plants'),
   ('Which animal gives us wool?', 'the sheep', ['the cow', 'the hen', 'the goat'], 'animals'),
   ('What is the hardest substance in the human body?', 'tooth enamel',
    ['bone', 'skin', 'hair'], 'human body'),
  ],
  'mid': [
   ('What is the process by which plants make their own food?', 'photosynthesis',
    ['respiration', 'digestion', 'transpiration'], 'plants'),
   ('Which planet is closest to the Sun?', 'Mercury', ['Venus', 'Earth', 'Mars'], 'earth and space'),
   ('Which planet is known as the Red Planet?', 'Mars', ['Venus', 'Jupiter', 'Mercury'], 'earth and space'),
   ('Which is the largest planet in our solar system?', 'Jupiter',
    ['Saturn', 'Neptune', 'Earth'], 'earth and space'),
   ('What force pulls objects towards the Earth?', 'gravity',
    ['friction', 'magnetism', 'pressure'], 'force and energy'),
   ('Which force slows a ball rolling on the ground?', 'friction',
    ['gravity', 'magnetism', 'buoyancy'], 'force and energy'),
   ('At what temperature does pure water boil at sea level?', '100°C',
    ['90°C', '0°C', '120°C'], 'matter'),
   ('At what temperature does pure water freeze?', '0°C',
    ['100°C', '-100°C', '32°C'], 'matter'),
   ('What is the change from liquid to gas called?', 'evaporation',
    ['condensation', 'melting', 'freezing'], 'matter'),
   ('What is the change from gas to liquid called?', 'condensation',
    ['evaporation', 'sublimation', 'melting'], 'matter'),
   ('Which organ pumps blood around the body?', 'the heart',
    ['the lungs', 'the liver', 'the kidney'], 'human body'),
   ('Which organ filters waste from the blood?', 'the kidney',
    ['the heart', 'the lungs', 'the stomach'], 'human body'),
   ('How many bones are there in an adult human body?', '206',
    ['201', '212', '198'], 'human body'),
   ('What is the nearest star to the Earth?', 'the Sun',
    ['the Moon', 'Sirius', 'Polaris'], 'earth and space'),
   ('Which gas do plants take in from the air to make food?', 'carbon dioxide',
    ['oxygen', 'nitrogen', 'hydrogen'], 'plants'),
   ('What is a magnet attracted to?', 'iron', ['wood', 'plastic', 'glass'], 'force and energy'),
   ('What do we call animals that are active at night?', 'nocturnal',
    ['diurnal', 'migratory', 'aquatic'], 'animals'),
   ('Which part of the plant carries water to the leaves?', 'the stem',
    ['the flower', 'the fruit', 'the seed'], 'plants'),
   ('What does a thermometer measure?', 'temperature',
    ['weight', 'length', 'time'], 'measurement'),
  ],
  'high': [
   ('What is the chemical symbol for water?', 'H₂O', ['CO₂', 'O₂', 'NaCl'], 'chemistry'),
   ('What is the chemical symbol for gold?', 'Au', ['Ag', 'Gd', 'Go'], 'chemistry'),
   ('What is the chemical symbol for sodium?', 'Na', ['So', 'S', 'Sd'], 'chemistry'),
   ('What is the SI unit of force?', 'the newton',
    ['the joule', 'the watt', 'the pascal'], 'physics'),
   ('What is the SI unit of energy?', 'the joule',
    ['the newton', 'the watt', 'the ampere'], 'physics'),
   ('What is the SI unit of electric current?', 'the ampere',
    ['the volt', 'the ohm', 'the watt'], 'physics'),
   ('Which part of the cell contains the genetic material?', 'the nucleus',
    ['the cytoplasm', 'the cell wall', 'the vacuole'], 'biology'),
   ('Which structure is found in plant cells but not animal cells?', 'the cell wall',
    ['the nucleus', 'the cytoplasm', 'the cell membrane'], 'biology'),
   ('What is the powerhouse of the cell?', 'the mitochondrion',
    ['the nucleus', 'the ribosome', 'the vacuole'], 'biology'),
   ('What is the green pigment in plants called?', 'chlorophyll',
    ['haemoglobin', 'melanin', 'carotene'], 'biology'),
   ('Which blood cells carry oxygen?', 'red blood cells',
    ['white blood cells', 'platelets', 'plasma cells'], 'biology'),
   ('What is the pH of a neutral solution?', '7', ['0', '14', '1'], 'chemistry'),
   ('An acid turns blue litmus paper', 'red', ['blue', 'green', 'colourless'], 'chemistry'),
   ('A base turns red litmus paper', 'blue', ['red', 'yellow', 'colourless'], 'chemistry'),
   ('What is the speed of light in a vacuum, approximately?', '300,000 km per second',
    ['300 km per second', '3,000 km per second', '30,000 km per second'], 'physics'),
   ('Which gas makes up about 78% of the air?', 'nitrogen',
    ['oxygen', 'carbon dioxide', 'argon'], 'chemistry'),
   ('What is the atomic number of an element?', 'the number of protons in its nucleus',
    ['the number of neutrons', 'the number of shells', 'its mass in grams'], 'chemistry'),
   ('Newton\'s first law is also known as the law of', 'inertia',
    ['gravitation', 'momentum', 'action and reaction'], 'physics'),
   ('What kind of energy does a moving object have?', 'kinetic energy',
    ['potential energy', 'chemical energy', 'nuclear energy'], 'physics'),
   ('What is the process by which water vapour forms clouds?', 'condensation',
    ['evaporation', 'precipitation', 'transpiration'], 'earth science'),
  ],
 },
 'Computer Science': {
  'low': [
   ('What does a keyboard help you do?', 'type letters and numbers',
    ['print on paper', 'hear sound', 'see pictures'], 'parts of a computer'),
   ('Which part of a computer shows you what you are doing?', 'the monitor',
    ['the keyboard', 'the mouse', 'the printer'], 'parts of a computer'),
   ('What is the brain of the computer called?', 'the CPU',
    ['the monitor', 'the keyboard', 'the printer'], 'parts of a computer'),
   ('Which key is used to make a space between words?', 'the spacebar',
    ['Enter', 'Shift', 'Escape'], 'using a computer'),
   ('Which key deletes the letter to the left of the cursor?', 'Backspace',
    ['Enter', 'Shift', 'Tab'], 'using a computer'),
   ('What do we call a set of instructions a computer follows?', 'a program',
    ['a picture', 'a folder', 'a screen'], 'basics'),
  ],
  'mid': [
   ('What does CPU stand for?', 'Central Processing Unit',
    ['Computer Personal Unit', 'Central Program Utility', 'Control Print Unit'], 'hardware'),
   ('What does RAM stand for?', 'Random Access Memory',
    ['Read Access Memory', 'Rapid Access Module', 'Run And Manage'], 'hardware'),
   ('How many bits are there in one byte?', '8', ['4', '16', '10'], 'data'),
   ('What does WWW stand for?', 'World Wide Web',
    ['World Wide Windows', 'Wide World Web', 'Web World Wide'], 'internet'),
   ('Which of these is used to search the internet?', 'a search engine',
    ['a spreadsheet', 'a printer', 'a scanner'], 'internet'),
   ('What is software?', 'the programs a computer runs',
    ['the physical parts of a computer', 'the electricity supply', 'the desk it sits on'], 'basics'),
   ('What is hardware?', 'the physical parts of a computer',
    ['the programs it runs', 'the internet', 'a type of file'], 'basics'),
   ('Which file type is usually a picture?', '.jpg', ['.docx', '.mp3', '.exe'], 'files'),
  ],
  'high': [
   ('What does HTML stand for?', 'HyperText Markup Language',
    ['High Text Machine Language', 'Hyperlink Text Making Language',
     'Home Tool Markup Language'], 'web'),
   ('Which language is used to style a web page?', 'CSS',
    ['HTML', 'Python', 'SQL'], 'web'),
   ('In programming, what does a loop do?', 'repeats a block of instructions',
    ['stores a value', 'ends the program', 'prints one line'], 'programming'),
   ('What is a variable in programming?', 'a named place to store a value',
    ['a fixed number', 'a type of loop', 'an error message'], 'programming'),
   ('How many kilobytes are there in one megabyte?', '1024',
    ['100', '1000', '512'], 'data'),
   ('What does an algorithm describe?', 'a step-by-step way of solving a problem',
    ['a kind of computer', 'a programming language', 'a storage device'], 'programming'),
   ('What does IP stand for in IP address?', 'Internet Protocol',
    ['Internal Program', 'Internet Provider', 'Input Process'], 'internet'),
   ('Which of these is an example of a bug?', 'a mistake in a program',
    ['an insect in the keyboard', 'a slow internet connection', 'a broken screen'], 'programming'),
   ('What is the binary number 1010 in decimal?', '10', ['8', '12', '1010'], 'data'),
   ('What does a firewall do?', 'controls what traffic reaches a computer',
    ['cools the processor', 'stores files', 'prints documents'], 'safety'),
  ],
 },
}

# ── Social Studies: written per board, because the syllabus is ──────
SOCIAL = {
 'INDIA': {
  'low': [
   ('What is the capital of India?', 'New Delhi', ['Mumbai', 'Kolkata', 'Chennai'], 'our country'),
   ('What is the national animal of India?', 'the tiger',
    ['the lion', 'the elephant', 'the peacock'], 'our country'),
   ('What is the national bird of India?', 'the peacock',
    ['the parrot', 'the crow', 'the eagle'], 'our country'),
   ('What is the national flower of India?', 'the lotus',
    ['the rose', 'the sunflower', 'the marigold'], 'our country'),
   ('How many colours are there in the Indian national flag?', 'three',
    ['two', 'four', 'five'], 'our country'),
   ('What is in the centre of the Indian national flag?', 'the Ashoka Chakra',
    ['a star', 'a lotus', 'a wheel of fire'], 'our country'),
   ('Which festival is known as the festival of lights?', 'Diwali',
    ['Holi', 'Eid', 'Onam'], 'festivals'),
   ('Which river is considered the holiest in India?', 'the Ganga',
    ['the Yamuna', 'the Godavari', 'the Krishna'], 'geography'),
  ],
  'mid': [
   ('Which is the longest river in India?', 'the Ganga',
    ['the Godavari', 'the Yamuna', 'the Narmada'], 'geography'),
   ('Which mountain range lies to the north of India?', 'the Himalayas',
    ['the Western Ghats', 'the Aravallis', 'the Vindhyas'], 'geography'),
   ('Who is called the Father of the Nation in India?', 'Mahatma Gandhi',
    ['Jawaharlal Nehru', 'Sardar Patel', 'Subhas Chandra Bose'], 'history'),
   ('In which year did India become independent?', '1947',
    ['1950', '1942', '1935'], 'history'),
   ('On which date is Republic Day celebrated in India?', '26 January',
    ['15 August', '2 October', '14 November'], 'history'),
   ('On which date is Independence Day celebrated in India?', '15 August',
    ['26 January', '2 October', '1 May'], 'history'),
   ('Which is the largest state in India by area?', 'Rajasthan',
    ['Madhya Pradesh', 'Maharashtra', 'Uttar Pradesh'], 'geography'),
   ('Which ocean lies to the south of India?', 'the Indian Ocean',
    ['the Pacific Ocean', 'the Atlantic Ocean', 'the Arctic Ocean'], 'geography'),
  ],
  'high': [
   ('Who was the first Prime Minister of India?', 'Jawaharlal Nehru',
    ['Mahatma Gandhi', 'Sardar Patel', 'Rajendra Prasad'], 'civics'),
   ('Who was the first President of India?', 'Dr Rajendra Prasad',
    ['Jawaharlal Nehru', 'Dr S. Radhakrishnan', 'Dr A.P.J. Abdul Kalam'], 'civics'),
   ('Which article of the Indian Constitution deals with the Right to Equality?',
    'Article 14', ['Article 21', 'Article 19', 'Article 32'], 'civics'),
   ('Which article of the Indian Constitution deals with the Right to Life?',
    'Article 21', ['Article 14', 'Article 19', 'Article 25'], 'civics'),
   ('When did the Constitution of India come into force?', '26 January 1950',
    ['15 August 1947', '26 November 1949', '2 October 1950'], 'civics'),
   ('Who is known as the chief architect of the Indian Constitution?',
    'Dr B. R. Ambedkar', ['Jawaharlal Nehru', 'Mahatma Gandhi', 'Sardar Patel'], 'civics'),
   ('How many states does India have as of 2024?', '28',
    ['29', '27', '30'], 'civics'),
   ('The Indian Parliament has how many houses?', 'two',
    ['one', 'three', 'four'], 'civics'),
   ('Which empire was ruled by Ashoka?', 'the Mauryan Empire',
    ['the Gupta Empire', 'the Mughal Empire', 'the Chola Empire'], 'history'),
   ('Who founded the Mughal Empire in India?', 'Babur',
    ['Akbar', 'Humayun', 'Shah Jahan'], 'history'),
   ('Who built the Taj Mahal?', 'Shah Jahan', ['Akbar', 'Aurangzeb', 'Babur'], 'history'),
  ],
 },
 'UK': {
  'low': [
   ('What is the capital city of England?', 'London',
    ['Manchester', 'Birmingham', 'Liverpool'], 'our country'),
   ('What is the capital city of Scotland?', 'Edinburgh',
    ['Glasgow', 'Aberdeen', 'Dundee'], 'our country'),
   ('What is the capital city of Wales?', 'Cardiff',
    ['Swansea', 'Newport', 'Bangor'], 'our country'),
   ('How many countries make up the United Kingdom?', 'four',
    ['three', 'two', 'five'], 'our country'),
   ('Which river runs through London?', 'the Thames',
    ['the Severn', 'the Mersey', 'the Tyne'], 'geography'),
  ],
  'mid': [
   ('What is the capital city of Northern Ireland?', 'Belfast',
    ['Dublin', 'Londonderry', 'Armagh'], 'our country'),
   ('Which is the longest river in the United Kingdom?', 'the Severn',
    ['the Thames', 'the Trent', 'the Mersey'], 'geography'),
   ('Which is the highest mountain in the United Kingdom?', 'Ben Nevis',
    ['Snowdon', 'Scafell Pike', 'Slieve Donard'], 'geography'),
   ('In which year did the Great Fire of London happen?', '1666',
    ['1605', '1666 BC', '1766'], 'history'),
   ('Who was the queen at the time of the Spanish Armada?', 'Elizabeth I',
    ['Victoria', 'Mary I', 'Anne'], 'history'),
   ('The Romans invaded Britain in AD', '43', ['1066', '410', '793'], 'history'),
   ('In which year was the Battle of Hastings?', '1066',
    ['1666', '1215', '1415'], 'history'),
  ],
  'high': [
   ('What is the name of the UK Parliament building in London?',
    'the Palace of Westminster', ['Buckingham Palace', 'Downing Street', 'the Tower of London'],
    'civics'),
   ('How many houses does the UK Parliament have?', 'two',
    ['one', 'three', 'four'], 'civics'),
   ('What are the two houses of the UK Parliament called?',
    'the House of Commons and the House of Lords',
    ['the Senate and the Congress', 'the Assembly and the Council',
     'the Upper Court and the Lower Court'], 'civics'),
   ('In which year did the Second World War end?', '1945',
    ['1939', '1918', '1950'], 'history'),
   ('Magna Carta was sealed in which year?', '1215',
    ['1066', '1415', '1605'], 'history'),
   ('Which ocean lies to the west of the United Kingdom?', 'the Atlantic Ocean',
    ['the Pacific Ocean', 'the Indian Ocean', 'the Arctic Ocean'], 'geography'),
  ],
 },
 'US': {
  'low': [
   ('What is the capital of the United States?', 'Washington, D.C.',
    ['New York City', 'Los Angeles', 'Boston'], 'our country'),
   ('How many states are there in the United States?', '50',
    ['48', '52', '51'], 'our country'),
   ('How many stripes are there on the US flag?', '13',
    ['50', '12', '15'], 'our country'),
   ('What do the stars on the US flag stand for?', 'the states',
    ['the original colonies', 'the presidents', 'the years'], 'our country'),
   ('Which bird is the national bird of the United States?', 'the bald eagle',
    ['the turkey', 'the robin', 'the cardinal'], 'our country'),
  ],
  'mid': [
   ('Who was the first President of the United States?', 'George Washington',
    ['Abraham Lincoln', 'Thomas Jefferson', 'John Adams'], 'history'),
   ('In which year was the Declaration of Independence signed?', '1776',
    ['1789', '1812', '1620'], 'history'),
   ('Which is the longest river in the United States?', 'the Missouri River',
    ['the Mississippi River', 'the Colorado River', 'the Rio Grande'], 'geography'),
   ('Which ocean lies to the west of the United States?', 'the Pacific Ocean',
    ['the Atlantic Ocean', 'the Indian Ocean', 'the Arctic Ocean'], 'geography'),
   ('Which US state is the largest by area?', 'Alaska',
    ['Texas', 'California', 'Montana'], 'geography'),
  ],
  'high': [
   ('How many branches does the US federal government have?', 'three',
    ['two', 'four', 'one'], 'civics'),
   ('What are the two houses of the US Congress?',
    'the Senate and the House of Representatives',
    ['the Commons and the Lords', 'the Assembly and the Council',
     'the Cabinet and the Court'], 'civics'),
   ('How many US senators does each state elect?', 'two',
    ['one', 'three', 'it depends on population'], 'civics'),
   ('Which president issued the Emancipation Proclamation?', 'Abraham Lincoln',
    ['George Washington', 'Thomas Jefferson', 'Ulysses S. Grant'], 'history'),
   ('The first ten amendments to the US Constitution are known as', 'the Bill of Rights',
    ['the Declaration', 'the Articles', 'the Federalist Papers'], 'civics'),
   ('In which year did the American Civil War end?', '1865',
    ['1776', '1812', '1901'], 'history'),
  ],
 },
}

# ── General Knowledge: shared, plus a board-flavoured tail ──────────
GK = {
 'low': [
  ('How many days are there in a week?', 'seven', ['five', 'six', 'ten'], 'everyday'),
  ('How many months are there in a year?', 'twelve', ['ten', 'eleven', 'thirteen'], 'everyday'),
  ('How many hours are there in a day?', '24', ['12', '20', '30'], 'everyday'),
  ('What colour do you get by mixing blue and yellow?', 'green',
   ['orange', 'purple', 'brown'], 'everyday'),
  ('How many continents are there on Earth?', 'seven', ['five', 'six', 'eight'], 'world'),
  ('Which is the largest ocean on Earth?', 'the Pacific Ocean',
   ['the Atlantic Ocean', 'the Indian Ocean', 'the Arctic Ocean'], 'world'),
 ],
 'mid': [
  ('Which is the tallest mountain in the world?', 'Mount Everest',
   ['K2', 'Kilimanjaro', 'Mont Blanc'], 'world'),
  ('Which is the largest desert in the world?', 'the Antarctic Desert',
   ['the Sahara', 'the Gobi', 'the Kalahari'], 'world'),
  ('Which is the largest country in the world by area?', 'Russia',
   ['Canada', 'China', 'the United States'], 'world'),
  ('How many players are there in a football (soccer) team on the field?', 'eleven',
   ['nine', 'ten', 'twelve'], 'sport'),
  ('How many players are there in a cricket team?', 'eleven',
   ['nine', 'ten', 'twelve'], 'sport'),
  ('How often are the Summer Olympic Games held?', 'every four years',
   ['every two years', 'every year', 'every five years'], 'sport'),
  ('Which animal is the largest living animal on Earth?', 'the blue whale',
   ['the African elephant', 'the giraffe', 'the great white shark'], 'nature'),
  ('Which is the fastest land animal?', 'the cheetah',
   ['the lion', 'the horse', 'the greyhound'], 'nature'),
 ],
 'high': [
  ('Who wrote the play "Romeo and Juliet"?', 'William Shakespeare',
   ['Charles Dickens', 'Jane Austen', 'John Keats'], 'literature'),
  ('Who proposed the theory of relativity?', 'Albert Einstein',
   ['Isaac Newton', 'Galileo Galilei', 'Niels Bohr'], 'science'),
  ('Who discovered penicillin?', 'Alexander Fleming',
   ['Louis Pasteur', 'Edward Jenner', 'Marie Curie'], 'science'),
  ('In which year did the First World War begin?', '1914',
   ['1918', '1939', '1905'], 'history'),
  ('What is the currency of Japan?', 'the yen',
   ['the won', 'the yuan', 'the rupee'], 'world'),
  ('Which organisation has its headquarters in New York and was founded in 1945?',
   'the United Nations', ['the World Bank', 'NATO', 'the Red Cross'], 'world'),
  ('Which gas is most responsible for the greenhouse effect from human activity?',
   'carbon dioxide', ['oxygen', 'nitrogen', 'helium'], 'environment'),
 ],
}


# ── Grouped tables for the two subjects that were running dry ───────
# Social Studies gets one set per region, because "which of these is an
# Indian state" is not a question a child on the UK curriculum should ever
# be asked. General Knowledge is shared, since it is the one subject that
# is deliberately not tied to a syllabus.
GROUPS['Social Studies'] = {}
GROUPS['General Knowledge'] = {
 'low': {
  'continent': ['Asia', 'Africa', 'Europe', 'Australia', 'Antarctica',
                'South America', 'North America'],
  'ocean': ['the Pacific Ocean', 'the Atlantic Ocean', 'the Indian Ocean',
            'the Arctic Ocean', 'the Southern Ocean'],
  'colour of the rainbow': ['red', 'orange', 'yellow', 'green', 'indigo', 'violet'],
  'day of the week': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
  'shape': ['circle', 'triangle', 'square', 'hexagon'],
 },
 'mid': {
  'musical instrument': ['guitar', 'piano', 'violin', 'flute', 'tabla', 'drum'],
  'sport played with a ball': ['football', 'basketball', 'cricket', 'tennis', 'volleyball'],
  'means of communication': ['telephone', 'email', 'letter', 'radio', 'television'],
  'natural disaster': ['earthquake', 'flood', 'cyclone', 'drought', 'landslide'],
  'planet': ['Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Neptune'],
 },
 'high': {
  'currency': ['the rupee', 'the pound', 'the dollar', 'the yen', 'the euro'],
  'language': ['Hindi', 'Spanish', 'Mandarin', 'Arabic', 'French'],
  'renewable energy source': ['solar power', 'wind power', 'hydro power', 'tidal power'],
  'international organisation': ['the United Nations', 'the World Health Organization',
                                 'UNICEF', 'UNESCO'],
  'branch of science': ['physics', 'chemistry', 'biology', 'astronomy', 'geology'],
 },
}

SOCIAL_GROUPS = {
 'INDIA': {
  'low': {
   'Indian festival': ['Diwali', 'Holi', 'Onam', 'Pongal', 'Baisakhi', 'Eid'],
   'Indian city': ['Mumbai', 'Chennai', 'Kolkata', 'Bengaluru', 'Jaipur', 'Hyderabad'],
   'Indian state': ['Kerala', 'Punjab', 'Gujarat', 'Odisha', 'Assam', 'Bihar'],
   'Indian river': ['the Ganga', 'the Yamuna', 'the Godavari', 'the Narmada', 'the Kaveri'],
  },
  'mid': {
   'country that borders India': ['Nepal', 'Bhutan', 'Bangladesh', 'Pakistan', 'China'],
   'Indian mountain range': ['the Himalayas', 'the Western Ghats', 'the Aravallis',
                             'the Vindhyas', 'the Satpuras'],
   'Indian monument': ['the Taj Mahal', 'the Red Fort', 'Qutub Minar', 'India Gate',
                       'Hawa Mahal'],
   'Indian classical dance': ['Bharatanatyam', 'Kathak', 'Odissi', 'Kathakali', 'Manipuri'],
  },
  'high': {
   'Indian freedom fighter': ['Mahatma Gandhi', 'Bhagat Singh', 'Rani Lakshmibai',
                              'Subhas Chandra Bose', 'Sardar Patel'],
   'fundamental right in the Indian Constitution': ['the Right to Equality',
     'the Right to Freedom', 'the Right against Exploitation',
     'the Right to Constitutional Remedies'],
   'Indian dynasty': ['the Mauryas', 'the Guptas', 'the Cholas', 'the Mughals'],
  },
 },
 'UK': {
  'low': {
   'country of the United Kingdom': ['England', 'Scotland', 'Wales', 'Northern Ireland'],
   'city in England': ['London', 'Manchester', 'Bristol', 'Leeds', 'Birmingham'],
   'UK river': ['the Thames', 'the Severn', 'the Mersey', 'the Tyne', 'the Trent'],
   'UK landmark': ['Stonehenge', 'Big Ben', 'the Tower of London', 'Hadrian\'s Wall'],
  },
  'mid': {
   'city in Scotland': ['Edinburgh', 'Glasgow', 'Aberdeen', 'Dundee', 'Inverness'],
   'city in Wales': ['Cardiff', 'Swansea', 'Newport', 'Bangor'],
   'UK mountain': ['Ben Nevis', 'Snowdon', 'Scafell Pike', 'Slieve Donard'],
   'sea around the United Kingdom': ['the North Sea', 'the Irish Sea',
                                     'the English Channel', 'the Celtic Sea'],
  },
  'high': {
   'British monarch': ['Elizabeth I', 'Victoria', 'Henry VIII', 'George III'],
   'period of British history': ['the Roman period', 'the Anglo-Saxon period',
                                 'the Tudor period', 'the Victorian era'],
   'part of the UK Parliament': ['the House of Commons', 'the House of Lords',
                                 'the monarch'],
  },
 },
 'US': {
  'low': {
   'US state': ['Texas', 'California', 'Florida', 'Ohio', 'Nevada', 'Maine'],
   'US city': ['New York City', 'Chicago', 'Houston', 'Seattle', 'Boston'],
   'US landmark': ['the Statue of Liberty', 'Mount Rushmore', 'the Grand Canyon',
                   'the Golden Gate Bridge'],
   'US national holiday': ['Independence Day', 'Thanksgiving', 'Memorial Day',
                           'Labor Day'],
   'US symbol': ['the bald eagle', 'the Stars and Stripes', 'the Liberty Bell'],
  },
  'mid': {
   'US river': ['the Mississippi River', 'the Missouri River', 'the Colorado River',
                'the Rio Grande', 'the Ohio River'],
   'Great Lake': ['Lake Superior', 'Lake Michigan', 'Lake Huron', 'Lake Erie',
                  'Lake Ontario'],
   'country that borders the United States': ['Canada', 'Mexico'],
   'US national park': ['Yellowstone', 'Yosemite', 'Zion', 'Everglades'],
  },
  'high': {
   'US President': ['George Washington', 'Abraham Lincoln', 'Thomas Jefferson',
                    'Franklin D. Roosevelt'],
   'branch of the US government': ['the legislative branch', 'the executive branch',
                                   'the judicial branch'],
   'original thirteen colony': ['Virginia', 'Massachusetts', 'Pennsylvania',
                                'Georgia', 'New York'],
  },
 },
}

BAND = {1: 'low', 2: 'low', 3: 'low', 4: 'mid', 5: 'mid', 6: 'mid', 7: 'high', 8: 'high'}
SOCIAL_FOR = {'CBSE': 'INDIA', 'ICSE': 'INDIA', 'UK_NATIONAL': 'UK', 'US_COMMON_CORE': 'US'}



# English chooses a/an by SOUND, not by spelling. "a unit" and "an hour"
# are both correct and both break any first-letter rule, so the exceptions
# are listed rather than guessed at.
SOUNDS_CONSONANT = ('uni', 'use', 'usu', 'euro', 'one', 'once', 'ubiqu')
SOUNDS_VOWEL = ('hour', 'honest', 'honour', 'heir')


def article(word):
    """Two mistakes make a bank look machine-made at a glance, and both were
       in it: "a output device", and then "an unit of measurement" after the
       first fix went by spelling alone."""
    w = str(word).lower()
    if w.startswith(SOUNDS_VOWEL): return 'an'
    if w.startswith(SOUNDS_CONSONANT): return 'a'
    return 'an' if w[:1] in 'aeiou' else 'a'

def _bands_upto(grade):
    """Which bands a grade may draw on — a window, not everything below it.

       The first version let every grade reach all the way down, which is
       why a grade 8 science file opened with "which of these is a farm
       animal". Revision has a place, but a thirteen-year-old's easy
       questions should be easy for a thirteen-year-old, not for a six-year-
       old. So grades 7 and 8 lose the infant band entirely, and grades 4-6
       keep one step of look-back."""
    if grade <= 3: return ['low']
    if grade <= 6: return ['low', 'mid']
    return ['mid', 'high']


def from_groups(subject, grade, board, rnd, difficulty):
    """One grouped table, asked three different ways.

       These are three different questions, not one question rephrased.
       "Which of these is a mammal" is recognition; "to which group does a
       whale belong" is classification and has a distinct stem for every
       member, which is where most of the yield comes from; "which of these
       is NOT a mammal" is the one that catches a child who has learned the
       list rather than the idea."""
    tables = GROUPS.get(subject, {})
    pools = {}
    for b in _bands_upto(grade):
        pools.update(tables.get(b, {}))
    if len(pools) < 4: return None
    form = rnd.choice(['is_a', 'which_group', 'not_a'])
    cat = rnd.choice(list(pools))

    if form == 'is_a':
        member = rnd.choice(pools[cat])
        others = [c for c in pools if c != cat and member not in pools[c]]
        if len(others) < 3: return None
        wrongs = [rnd.choice(pools[c]) for c in rnd.sample(others, 3)]
        return make(board, subject, grade, difficulty, cat,
                    f'Which of these is {article(cat)} {cat}?', member, wrongs,
                    f'Think about what makes something {article(cat)} {cat}.',
                    f'{member.capitalize()} is {article(cat)} {cat}.', rnd=rnd)

    if form == 'which_group':
        member = rnd.choice(pools[cat])
        # a member that sits in two groups has no single right answer
        if sum(1 for c in pools if member in pools[c]) != 1: return None
        others = [c for c in pools if c != cat]
        if len(others) < 3: return None
        return make(board, subject, grade, difficulty, cat,
                    f'To which group does "{member}" belong?', cat,
                    rnd.sample(others, 3),
                    'Ask what kind of thing it is.',
                    f'{member.capitalize()} is {article(cat)} {cat}.', rnd=rnd)

    # not_a — the odd one out
    others = [c for c in pools if c != cat]
    if len(others) < 1: return None
    odd_cat = rnd.choice(others)
    odd = rnd.choice([m for m in pools[odd_cat] if m not in pools[cat]] or [None])
    if not odd: return None
    ins = [m for m in pools[cat] if m != odd]
    if len(ins) < 3: return None
    return make(board, subject, grade, difficulty, cat,
                f'Which of these is NOT {article(cat)} {cat}?', odd, rnd.sample(ins, 3),
                'Three of them belong together.',
                f'{odd.capitalize()} is {article(odd_cat)} {odd_cat}, not {article(cat)} {cat}.', rnd=rnd)


def from_facts(table, subject, grade, board, rnd, difficulty):
    items = []
    for b in _bands_upto(grade):
        items += table.get(b, [])
    if not items: return None
    q, a, w, topic = rnd.choice(items)
    return make(board, subject, grade, difficulty, topic, q, a, list(w),
                'Think about what you have learned on this topic.',
                f'The answer is {a}.', rnd=rnd)


def _all_group_questions(subject, grade, board, rnd):
    """Every grouped question the tables can honestly make, once each.

       Sampling at random was the mistake: the pool of distinct stems is
       finite, so the first difficulty band drank it dry and the other two
       came out empty. Enumerating instead means the count is whatever the
       content supports, and the difficulty is decided by what the question
       asks rather than by which loop happened to run first."""
    out = []
    tables = GROUPS.get(subject, {})
    for b in _bands_upto(grade):
        pools = tables.get(b, {})
        if len(pools) < 4: continue
        cats = list(pools)
        for cat in cats:
            others = [c for c in cats if c != cat]
            if len(others) < 3: continue

            # recognition — the easiest thing you can ask about a group
            member = pools[cat][0]
            spread = [c for c in others if member not in pools[c]]
            if len(spread) >= 3:
                q = make(board, subject, grade, 'easy', cat,
                         f'Which of these is {article(cat)} {cat}?', member,
                         [pools[c][0] for c in spread[:3]],
                         f'Think about what makes something {article(cat)} {cat}.',
                         f'{member.capitalize()} is {article(cat)} {cat}.', rnd=rnd)
                if q: out.append(q)

            # classification — one per member, and the bulk of the yield
            for m in pools[cat]:
                if sum(1 for c in cats if m in pools[c]) != 1: continue
                q = make(board, subject, grade, 'medium', cat,
                         f'To which group does "{m}" belong?', cat,
                         [c for c in others][:3],
                         'Ask what kind of thing it is.',
                         f'{m.capitalize()} is {article(cat)} {cat}.', rnd=rnd)
                if q: out.append(q)

            # exclusion — catches the child who learned the list, not the idea
            ins = [m for m in pools[cat]]
            odd_cat = next((c for c in others if pools[c] and pools[c][0] not in ins), None)
            if odd_cat and len(ins) >= 3:
                odd = pools[odd_cat][0]
                q = make(board, subject, grade, 'hard', cat,
                         f'Which of these is NOT {article(cat)} {cat}?', odd, ins[:3],
                         'Three of them belong together.',
                         f'{odd.capitalize()} is {article(odd_cat)} {odd_cat}, '
                         f'not {article(cat)} {cat}.', rnd=rnd)
                if q: out.append(q)
    return out


def _all_fact_questions(table, subject, grade, board, rnd):
    """Facts, once each. A fact from a band below the grade is easier for
       that grade than one from its own band — which is what difficulty
       means here, rather than a number pulled out of the air."""
    order = ['low', 'mid', 'high']
    here = order.index(BAND[grade])
    out = []
    for b in _bands_upto(grade):
        dist = here - order.index(b)
        for i, (q, a, w, topic) in enumerate(table.get(b, [])):
            # Facts from below the grade are easier for it. Within the
            # grade's own band there is no such signal, so they alternate
            # rather than all landing on 'hard' and leaving the middle of
            # the file empty.
            diff = ('easy' if dist >= 2 else 'medium' if dist == 1
                    else ('medium' if i % 2 else 'hard'))
            item = make(board, subject, grade, diff, topic, q, a, list(w),
                        'Think about what you have learned on this topic.',
                        f'The answer is {a}.', rnd=rnd)
            if item: out.append(item)
    return out


def build_file(board, subject, grade, per_difficulty=50):
    rnd = random.Random(f'{board}|{subject}|{grade}')

    if subject == 'Social Studies':
        GROUPS['Social Studies'] = SOCIAL_GROUPS[SOCIAL_FOR[board]]
        facts = SOCIAL[SOCIAL_FOR[board]]
    elif subject == 'General Knowledge':
        facts = GK
    else:
        facts = FACTS.get(subject, {})

    pool = _all_group_questions(subject, grade, board, rnd) + \
           _all_fact_questions(facts, subject, grade, board, rnd)

    # one stem, once
    seen, out = set(), []
    for q in pool:
        if q['question'] in seen: continue
        seen.add(q['question']); out.append(q)

    # cap each difficulty at the target rather than truncating the file, so
    # a subject with a lot of easy content does not arrive as an easy file
    by = {'easy': [], 'medium': [], 'hard': []}
    for q in out: by[q['difficulty']].append(q)
    rnd.shuffle(by['easy']); rnd.shuffle(by['medium']); rnd.shuffle(by['hard'])
    return by['easy'][:per_difficulty] + by['medium'][:per_difficulty] + by['hard'][:per_difficulty]
