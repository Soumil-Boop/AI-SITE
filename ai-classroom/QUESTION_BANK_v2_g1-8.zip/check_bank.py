# -*- coding: utf-8 -*-
"""Check the bank, without asking the thing that built it.

A generator that computes its own answers cannot get the arithmetic wrong,
which is exactly why it must not be the thing that certifies itself: if the
template has the wrong idea of what the question means, it will produce a
confidently wrong answer and a matching explanation, and every internal
check will agree with it.

So the arithmetic here is re-derived from the printed stem by a parser that
has never seen the generator, using nothing but the words a student would
read. Anything it can parse, it re-solves. Anything it cannot, it says so —
an unverified question is reported as unverified rather than counted as a
pass, because a checker that quietly skips what it cannot do is worse than
no checker at all.
"""
import json, os, re, sys
from fractions import Fraction

# The syllabus the bank claims to cover, imported from the generator so the
# two cannot drift apart. This is the one thing the checker is allowed to
# take from the generator: what it was ASKED to cover, never what it produced.
try:
    from gen_math import SYLLABUS
except Exception:
    SYLLABUS = {}

FAILS, WARNS, CHECKED = [], [], 0


def fail(path, q, why):  FAILS.append((path, q.get('id', '?'), q.get('question', '')[:70], why))
def warn(path, q, why):  WARNS.append((path, q.get('id', '?'), q.get('question', '')[:70], why))


# ── the independent solver ──────────────────────────────────────────
def num(s):
    """A number out of a printed answer: 42, 3.5, 7/8, '45 cm³', '₹120'."""
    s = str(s).strip()
    s = re.sub(r'^[₹£$]', '', s)
    # strip any trailing unit, whether it is a symbol or words:
    # "45 cm³", "80 km per hour", "3 hours", "₹312.50"
    s = re.sub(r'[²³]', '', s)
    s = re.sub(r'\s*(cm|mm|in|m|km|miles?|hours?|kg|g)\b.*$', '', s, flags=re.I)
    s = s.replace(',', '').replace('−', '-').replace('°', '').strip()
    m = re.fullmatch(r'(-?\d+)\s*/\s*(\d+)', s)
    if m: return Fraction(int(m.group(1)), int(m.group(2)))
    try: return Fraction(s)
    except Exception: return None


def solve(stem):
    """Re-solve the printed question. Returns a value, or None for 'I cannot
       read this one' — never a guess."""
    s = stem.replace('−', '-').replace('×', '*').replace('÷', '/')

    # a + b = ?   /   a - b = ?   /   a * b = ?   /   a / b = ?
    m = re.fullmatch(r'\(?(-?\d+(?:\.\d+)?)\)?\s*([+\-*/])\s*\(?(-?\d+(?:\.\d+)?)\)?\s*=\s*\?', s.strip())
    if m:
        a, op, b = Fraction(m.group(1)), m.group(2), Fraction(m.group(3))
        return {'+': a + b, '-': a - b, '*': a * b, '/': a / b if b else None}[op]

    # n/d + n/d = ?
    m = re.fullmatch(r'(\d+)/(\d+)\s*\+\s*(\d+)/(\d+)\s*=\s*\?', s.strip())
    if m:
        a, b, c, d = map(int, m.groups())
        return Fraction(a, b) + Fraction(c, d)

    # What is p% of n?
    m = re.fullmatch(r'What is (\d+)% of (\d+)\?', s.strip())
    if m: return Fraction(int(m.group(1)) * int(m.group(2)), 100)

    # What is 1/d of n?
    m = re.fullmatch(r'What is 1/(\d+) of (\d+)\?', s.strip())
    if m: return Fraction(int(m.group(2)), int(m.group(1)))

    # What is half / a quarter of n?
    m = re.fullmatch(r'What is (half|a quarter) of (\d+)\?', s.strip())
    if m: return Fraction(int(m.group(2)), 2 if m.group(1) == 'half' else 4)

    # What is b^e?
    m = re.fullmatch(r'What is (\d+)\^(\d+)\?', s.strip())
    if m: return Fraction(int(m.group(1)) ** int(m.group(2)))

    # What is n²?  /  square root of n
    m = re.fullmatch(r'What is (\d+)²\?', s.strip())
    if m: return Fraction(int(m.group(1)) ** 2)
    m = re.fullmatch(r'What is the square root of (\d+)\?', s.strip())
    if m:
        n = int(m.group(1)); r = int(round(n ** .5))
        return Fraction(r) if r * r == n else None

    # rectangle area / perimeter, from the printed measurements
    m = re.fullmatch(r'A rectangle is (\d+) (\w+) by (\d+) \w+\. What is its area\?', s.strip())
    if m: return Fraction(int(m.group(1)) * int(m.group(3)))
    m = re.fullmatch(r'A rectangle is (\d+) (\w+) long and (\d+) \w+ wide\. What is its perimeter\?', s.strip())
    if m: return Fraction(2 * (int(m.group(1)) + int(m.group(3))))

    # triangle area
    m = re.fullmatch(r'A triangle has a base of (\d+) \w+ and a height of (\d+) \w+\. What is its area\?', s.strip())
    if m: return Fraction(int(m.group(1)) * int(m.group(2)), 2)

    # cuboid volume
    m = re.fullmatch(r'A box measures (\d+) (\w+) . (\d+) \w+ . (\d+) \w+\. What is its volume\?', s.strip())
    if m: return Fraction(int(m.group(1)) * int(m.group(3)) * int(m.group(4)))

    # third angle of a triangle
    m = re.fullmatch(r'Two angles of a triangle are (\d+)° and (\d+)°\. What is the third\?', s.strip())
    if m: return Fraction(180 - int(m.group(1)) - int(m.group(2)))

    # average of a list
    m = re.fullmatch(r'What is the average of ([\d, ]+)\?', s.strip())
    if m:
        vals = [int(x) for x in m.group(1).split(',')]
        return Fraction(sum(vals), len(vals))

    # solve for x: ax + c = b
    m = re.fullmatch(r'Solve for x: (\d+)x \+ (\d+) = (\d+)', s.strip())
    if m:
        a, c, b = map(int, m.groups())
        return Fraction(b - c, a)

    # solve for x: ax + b = cx + d
    m = re.fullmatch(r'Solve for x: (\d+)x \+ (\d+) = (\d+)x \+ (\d+)', s.strip())
    if m:
        a, b, c, d = map(int, m.groups())
        return Fraction(d - b, a - c) if a != c else None

    # ax = b
    m = re.fullmatch(r'If (\d+)x = (\d+), what is x\?', s.strip())
    if m: return Fraction(int(m.group(2)), int(m.group(1)))

    # simple interest
    m = re.fullmatch(r'Find the simple interest on [₹£$]([\d.]+) at (\d+)% per year for (\d+) years?\.', s.strip())
    if m:
        p, r, t = Fraction(m.group(1)), int(m.group(2)), int(m.group(3))
        return p * r * t / 100


    # ── the multi-step questions ────────────────────────────────────
    # These were added because "hard" had meant "the same single step with
    # bigger numbers". They are also exactly where a silent arithmetic bug
    # would hide, so every one of them is re-solved here — the profit-and-
    # loss template shipped a wrong answer precisely because this checker
    # could not read it and counted it as unverified.

    m = re.fullmatch(r'A car covers (\d+) (?:km|miles) in (\d+) hours\. '
                     r'What is its average speed\?', s.strip())
    if m: return Fraction(int(m.group(1)), int(m.group(2)))

    m = re.fullmatch(r'A train travels (\d+) (?:km|miles) at a steady (\d+) '
                     r'(?:km|miles) per hour\. How long does the journey take\?', s.strip())
    if m: return Fraction(int(m.group(1)), int(m.group(2)))

    m = re.fullmatch(r'The average of (\d+) numbers is (\d+)\. \d+ of them are '
                     r'([\d, ]+)\. What is the last number\?', s.strip())
    if m:
        n, mean = int(m.group(1)), int(m.group(2))
        vals = [int(x) for x in m.group(3).split(',')]
        return Fraction(mean * n - sum(vals))

    m = re.fullmatch(r'The price of a phone is [₹£$]([\d.]+)\. It rises by (\d+)% '
                     r'and then falls by (\d+)%\. What is the final price\?', s.strip())
    if m:
        base, up, down = Fraction(m.group(1)), int(m.group(2)), int(m.group(3))
        after = base * (100 + up) / 100
        return after * (100 - down) / 100

    m = re.fullmatch(r'\w+ and \w+ share money in the ratio (\d+):(\d+)\. \w+ gets '
                     r'[₹£$]([\d.]+) more than \w+\. How much is shared altogether\?', s.strip())
    if m:
        a, b, diff = int(m.group(1)), int(m.group(2)), Fraction(m.group(3))
        k = diff / (b - a)
        return (a + b) * k

    m = re.fullmatch(r'\w+ thinks of a number, multiplies it by (\d+) and adds (\d+)\. '
                     r'The result is (\d+)\. What was the number\?', s.strip())
    if m:
        k, c, total = map(int, m.groups())
        return Fraction(total - c, k)

    m = re.fullmatch(r'A garden is (\d+) m by (\d+) m\. A path (\d+) m wide runs all the '
                     r'way around the outside\. What is the area of the path\?', s.strip())
    if m:
        w, h, p = map(int, m.groups())
        return Fraction((w + 2*p) * (h + 2*p) - w * h)

    m = re.fullmatch(r'\w+ can paint a wall in (\d+) hours and \w+ can paint it in (\d+) '
                     r'hours\. Working together, how many hours will it take\?', s.strip())
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        return Fraction(a * b, a + b)

    m = re.fullmatch(r'An item bought for [₹£$]([\d.]+) is sold at a (\d+)% (profit|loss)\. '
                     r'What is the selling price\?', s.strip())
    if m:
        cp, pct, kind = Fraction(m.group(1)), int(m.group(2)), m.group(3)
        gain = cp * pct / 100
        return cp + gain if kind == 'profit' else cp - gain

    m = re.fullmatch(r'Find the compound interest on [₹£$]([\d.]+) at (\d+)% per year '
                     r'for 2 years\.', s.strip())
    if m:
        p, r = Fraction(m.group(1)), Fraction(m.group(2))
        a1 = p * (100 + r) / 100
        return (a1 * (100 + r) / 100) - p

    m = re.fullmatch(r'\w+ had [₹£$]([\d.]+)\. She spent 1/(\d+) of it on books and '
                     r'1/(\d+) of what was left on food\. How much is left now\?', s.strip())
    if m:
        t, d1, d2 = Fraction(m.group(1)), int(m.group(2)), int(m.group(3))
        left = t - t / d1
        return left - left / d2

    m = re.fullmatch(r'\w+ buys (\d+) notebooks at [₹£$]([\d.]+) each and (\d+) pens at '
                     r'[₹£$]([\d.]+) each\. A (\d+)% discount is given on the total\. '
                     r'How much does \w+ pay\?', s.strip())
    if m:
        n1, p1, n2, p2, pct = (Fraction(x) for x in m.groups())
        sub = n1 * p1 + n2 * p2
        return sub * (100 - pct) / 100

    return None


READ_CAP = {1: 20, 2: 22, 3: 25, 4: 28, 5: 32, 6: 36, 7: 40, 8: 44}


def check_file(path):
    global CHECKED
    with open(path, encoding='utf-8') as f:
        doc = json.load(f)
    qs = doc.get('questions', [])
    if doc.get('count') != len(qs):
        FAILS.append((path, '-', '-', f"count says {doc.get('count')} but there are {len(qs)}"))

    stems, ids = {}, {}
    diffs = {'easy': 0, 'medium': 0, 'hard': 0}
    unparsed = 0

    for q in qs:
        CHECKED += 1
        # ── shape ──
        for k in ('id', 'question', 'options', 'answer', 'hint', 'explanation',
                  'topic', 'difficulty', 'grade', 'board', 'subject', 'source'):
            if k not in q: fail(path, q, f'missing field "{k}"')
        opts = q.get('options', [])
        if len(opts) != 4:                       fail(path, q, f'{len(opts)} options, expected 4')
        if len(set(map(str, opts))) != len(opts): fail(path, q, 'two options are the same')
        if str(q.get('answer')) not in map(str, opts): fail(path, q, 'the answer is not among the options')
        if q.get('difficulty') not in diffs:     fail(path, q, f'unknown difficulty {q.get("difficulty")!r}')
        else: diffs[q['difficulty']] += 1
        if q.get('source') == 'imported' and not q.get('attribution'):
            fail(path, q, 'imported without attribution')

        # ── not two of the same question ──
        if q.get('question') in stems: fail(path, q, 'duplicate question in the same file')
        stems[q.get('question')] = 1
        if q.get('id') in ids:         fail(path, q, 'duplicate id in the same file')
        ids[q.get('id')] = 1

        # ── the arithmetic, re-derived from the printed words ──
        want = solve(q.get('question', ''))
        if want is None:
            unparsed += 1
        else:
            got = num(q.get('answer'))
            if got is None:
                fail(path, q, f'answer {q.get("answer")!r} is not a number I can read')
            elif got != want:
                fail(path, q, f'answer says {q.get("answer")} but the question works out to {want}')
            # a distractor that is also correct makes the question unanswerable
            for o in opts:
                if str(o) != str(q.get('answer')) and num(o) is not None and num(o) == want:
                    fail(path, q, f'distractor {o!r} is also a correct answer')

        # ── is it readable at this grade ──
        g = q.get('grade') or 8
        words = len(re.findall(r"[\w'’/%°²³.-]+", q.get('question', '')))
        if words > READ_CAP.get(g, 44):
            warn(path, q, f'{words} words is long for grade {g}')

        # ── does the explanation actually explain this question ──
        if str(q.get('answer')).strip('₹£$ cm³in²').lower() not in q.get('explanation', '').lower():
            warn(path, q, 'the explanation never states the answer')

    for d, n in diffs.items():
        if n == 0: FAILS.append((path, '-', '-', f'no {d} questions at all'))

    # ── does the file actually cover the grade it claims to? ──
    # A topic listed in the syllabus but never produced is the failure mode
    # nothing else here would catch: every question in the file is correct,
    # and a whole strand of the year is simply missing. Two were, on the
    # first build, because the syllabus named templates that did not exist.
    # A non-maths file cannot be re-solved, so what is checked instead is
    # that it admits as much: written questions must carry review: pending,
    # or the bank is claiming a guarantee it does not have.
    if doc.get('subject') not in ('Math',):
        for q in qs:
            if q.get('source') == 'generated' and q.get('subject') != 'English':
                fail(path, q, 'claims source "generated" but its answer is a fact, not a computation')
            if q.get('source') == 'original' and q.get('review') != 'pending':
                fail(path, q, 'written by hand but not flagged for review')

    if doc.get('subject') == 'Math' and doc.get('grade') in SYLLABUS:
        want = set(SYLLABUS[doc['grade']])
        have = {q.get('topic') for q in qs}
        for missing in sorted(want - have):
            FAILS.append((path, '-', '-', f'syllabus topic "{missing}" produced no questions'))
        thin = sorted(t for t in (want & have)
                      if sum(1 for q in qs if q.get('topic') == t) < 3)
        for t in thin:
            WARNS.append((path, '-', '-', f'only a handful of "{t}" questions'))
    return len(qs), unparsed


def main(root):
    files = []
    for dirpath, _, names in os.walk(root):
        for n in names:
            # INDEX.JSON is the bank's table of contents, not a question file
            if n.upper() == 'INDEX.JSON': continue
            if n.upper().endswith('.JSON'): files.append(os.path.join(dirpath, n))
    files.sort()
    total, unparsed = 0, 0
    for p in files:
        n, u = check_file(p); total += n; unparsed += u

    print(f'{len(files)} files, {total} questions')
    print(f'{total - unparsed} re-solved independently from the printed question; '
          f'{unparsed} could not be parsed by the checker '
          f'({(total - unparsed) * 100 // max(1, total)}% verified)')
    print(f'{len(WARNS)} warning(s), {len(FAILS)} failure(s)')
    for p, i, s, w in WARNS[:8]:
        print(f'  ! {os.path.basename(p)}  {s}  — {w}')
    if len(WARNS) > 8: print(f'  … and {len(WARNS) - 8} more warnings')
    for p, i, s, w in FAILS[:20]:
        print(f'  ✗ {os.path.basename(p)}  {s}  — {w}')
    if len(FAILS) > 20: print(f'  … and {len(FAILS) - 20} more failures')
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else 'QUESTION_BANK'))
