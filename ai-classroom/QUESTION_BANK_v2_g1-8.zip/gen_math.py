# -*- coding: utf-8 -*-
"""Maths questions, generated so that the answer cannot be wrong.

The point of generating rather than writing is not speed, it is that the
answer is computed from the same numbers the question is printed from. A
written question bank has typos in the answer key; this one cannot, because
there is no answer key — there is arithmetic.

What generation cannot give you is interest. So the templates carry the
things a person would have thought about anyway: the distractors are the
answers a child actually gets when they make the usual mistake, the
contexts are local to the board, and the wording is checked against the
reading age of the grade.

Everything below is original. Nothing is copied from a past paper or a
textbook.
"""
import hashlib, json, os, random, re
from fractions import Fraction


def value_of(s):
    """The number a printed option actually represents, or None if it is not
       a number at all. Used to throw away distractors that are equal to the
       answer in value while differing as text — 4/8 against 1/2 is the case
       that matters, and it makes a question that punishes a correct child."""
    s = str(s).strip()
    s = re.sub(r'^[₹£$]', '', s)
    s = re.sub(r'\s*(cm|in|m)?[²³]?\s*$', '', s)
    s = s.replace(',', '').replace('−', '-').replace('°', '')
    m = re.fullmatch(r'(-?\d+)\s*/\s*(\d+)', s)
    if m:
        try: return Fraction(int(m.group(1)), int(m.group(2)))
        except ZeroDivisionError: return None
    try: return Fraction(s)
    except Exception: return None

BOARDS = {
    'CBSE':           dict(cur='₹', unit='metric', spell='en-IN', names=[
        'Aarav', 'Diya', 'Kabir', 'Meera', 'Rohan', 'Ananya', 'Ishaan', 'Saanvi',
        'Vihaan', 'Nisha', 'Arjun', 'Tara']),
    'ICSE':           dict(cur='₹', unit='metric', spell='en-IN', names=[
        'Rhea', 'Aditya', 'Zara', 'Neel', 'Myra', 'Kian', 'Avni', 'Dev',
        'Sara', 'Reyansh', 'Kiara', 'Om']),
    'UK_NATIONAL':    dict(cur='£', unit='metric', spell='en-GB', names=[
        'Olivia', 'Noah', 'Amelia', 'Leo', 'Isla', 'Freddie', 'Ava', 'Oscar',
        'Poppy', 'Arthur', 'Mia', 'Theo']),
    'US_COMMON_CORE': dict(cur='$', unit='customary', spell='en-US', names=[
        'Emma', 'Liam', 'Sofia', 'Mason', 'Ava', 'Ethan', 'Harper', 'Lucas',
        'Zoe', 'Elijah', 'Maya', 'Caleb']),
}

# ── Which strands belong to which grade ─────────────────────────────
# Taken from the published syllabus outlines, which are statements of fact
# about what a grade covers and carry no copyright. Where boards genuinely
# differ the difference is noted rather than averaged away: UK Year 3 meets
# formal division a little later than CBSE Class 3, and the US sequence puts
# fractions on a number line earlier than either.
SYLLABUS = {
    1: ['count', 'add_small', 'sub_small', 'compare', 'shapes2d', 'ordinal',
        'money_simple', 'time_oclock', 'pattern'],
    2: ['place_value', 'add_regroup', 'sub_regroup', 'times_easy', 'half_quarter',
        'money_change', 'time_half', 'measure_len', 'shapes2d'],
    3: ['times_table', 'divide_simple', 'place_value', 'fractions_unit',
        'measure_len', 'perimeter', 'time_min', 'money_change', 'data_pict'],
    4: ['multiply_2d', 'divide_remainder', 'factors', 'fractions_equiv',
        'decimals_intro', 'area_rect', 'perimeter', 'angles_kind', 'roman'],
    5: ['decimals_ops', 'fractions_ops', 'percent_intro', 'volume_cuboid',
        'average', 'large_numbers', 'hcf_lcm', 'area_rect', 'angles_kind'],
    6: ['integers', 'ratio', 'algebra_intro', 'percent', 'area_rect',
        'mean', 'primes', 'fractions_ops', 'decimals_ops'],
    7: ['integers_ops', 'rational', 'equation_simple', 'angles_triangle',
        'area_triangle', 'exponents', 'profit_loss', 'percent', 'mean'],
    8: ['linear_equation', 'squares_roots', 'exponents', 'compare_quantities',
        'algebra_identity', 'mensuration_cyl', 'factorise', 'proportion',
        'rational', 'interest'],
}

# Reading-age ceiling per grade, in words per sentence. A maths question that
# is hard to read is not a hard maths question, it is a reading test.
MAX_WORDS = {1: 12, 2: 14, 3: 17, 4: 20, 5: 40, 6: 44, 7: 48, 8: 52}

# What 'hard' draws on from grade 5 up. Below grade 5 a hard question is
# still a single step with bigger numbers, which at that age is right.
SYLLABUS_HARD = {
    5: ['ms_shopping', 'ms_fraction_remainder', 'ms_average_missing', 'ms_speed',
        'hcf_lcm', 'decimals_ops'],
    6: ['ms_shopping', 'ms_percent_change', 'ms_ratio_difference', 'ms_algebra_word',
        'ms_speed', 'ms_average_missing'],
    7: ['ms_percent_change', 'ms_ratio_difference', 'ms_algebra_word', 'ms_area_path',
        'ms_speed', 'profit_loss', 'ms_work_rate'],
    8: ['ms_compound_interest', 'ms_percent_change', 'ms_area_path', 'ms_work_rate',
        'ms_algebra_word', 'ms_ratio_difference', 'factorise', 'algebra_identity',
        'mensuration_cyl'],
}


def money(board, amount):
    """Currency the way the board writes it, and never with a stray .00."""
    c = BOARDS[board]['cur']
    if abs(amount - round(amount)) < 1e-9:
        return f'{c}{int(round(amount))}'
    return f'{c}{amount:.2f}'


class Ctx:
    """Everything a template needs to write one question, plus the random
       source. Seeded per file so a rebuild produces the same bank — a
       regenerated question that changes its own answer would invalidate
       every stored result that points at it."""
    def __init__(self, board, grade, difficulty, rnd):
        self.board, self.grade, self.difficulty, self.rnd = board, grade, difficulty, rnd
        self.cfg = BOARDS[board]

    def name(self):     return self.rnd.choice(self.cfg['names'])
    def two_names(self):
        a, b = self.rnd.sample(self.cfg['names'], 2)
        return a, b
    def money(self, n):  return money(self.board, n)
    # 'maths' in India and the UK, 'math' in the US.
    def maths(self):     return 'math' if self.cfg['spell'] == 'en-US' else 'maths'


def band(ctx, easy, medium, hard):
    """Pick a number range for the difficulty in play."""
    return {'easy': easy, 'medium': medium, 'hard': hard}[ctx.difficulty]


# ════════════════════════════════════════════════════════════════════
#  The templates.
#
#  Each returns (stem, answer, wrongs, hint, explanation). The answer is
#  always computed. `wrongs` are the results of specific, named mistakes —
#  a distractor that is merely "the answer plus one" teaches nothing and is
#  easy to eliminate; a distractor that is what you get by forgetting to
#  carry is the whole point of asking.
# ════════════════════════════════════════════════════════════════════

def t_count(ctx):
    hi = band(ctx, 20, 60, 100)
    step = ctx.rnd.choice([1, 2, 5, 10] if ctx.difficulty != 'easy' else [1, 2])
    start = ctx.rnd.randint(1, max(2, hi - step * 4))
    seq = [start + step * i for i in range(4)]
    ans = seq[-1] + step
    return (f'What number comes next? {", ".join(map(str, seq))}, ?',
            ans,
            [ans + step, ans - step, seq[-1] + 1],          # over-stepped, under-stepped, counted by one
            f'Look at how much the numbers go up by each time.',
            f'The numbers go up by {step} each time, so after {seq[-1]} comes {ans}.')


def t_add_small(ctx):
    hi = band(ctx, 10, 20, 50)
    a, b = ctx.rnd.randint(1, hi), ctx.rnd.randint(1, hi)
    return (f'{a} + {b} = ?', a + b,
            [a + b + 1, a + b - 1, abs(a - b)],             # miscount up, miscount down, subtracted instead
            'Try counting on from the bigger number.',
            f'{a} + {b} = {a + b}.')


def t_sub_small(ctx):
    hi = band(ctx, 10, 20, 50)
    a = ctx.rnd.randint(2, hi); b = ctx.rnd.randint(1, a)
    return (f'{a} − {b} = ?', a - b,
            [a + b, a - b + 1, a - b - 1],                  # added instead, and two miscounts
            'Count back from the bigger number.',
            f'{a} − {b} = {a - b}.')


def t_compare(ctx):
    hi = band(ctx, 20, 100, 1000)
    a, b = ctx.rnd.randint(1, hi), ctx.rnd.randint(1, hi)
    while a == b: b = ctx.rnd.randint(1, hi)
    bigger = max(a, b)
    return (f'Which number is greater, {a} or {b}?', bigger,
            [min(a, b), a + b, abs(a - b)],
            'Compare the digits from the left.',
            f'{bigger} is greater than {min(a, b)}.')


def t_shapes2d(ctx):
    shapes = [('triangle', 3), ('square', 4), ('rectangle', 4), ('pentagon', 5),
              ('hexagon', 6), ('octagon', 8)]
    if ctx.difficulty == 'easy': shapes = shapes[:4]
    nm, n = ctx.rnd.choice(shapes)
    return (f'How many sides does a {nm} have?', n,
            [n + 1, n - 1, n + 2],
            'Count the straight edges.',
            f'A {nm} has {n} sides.')


def t_ordinal(ctx):
    words = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh',
             'eighth', 'ninth', 'tenth']
    k = ctx.rnd.randint(1, band(ctx, 5, 8, 10))
    nm = ctx.name()
    return (f'{nm} is standing {words[k-1]} in a queue. How many people are in front of {nm}?',
            k - 1, [k, k + 1, max(0, k - 2)],
            'The people in front are everyone before them.',
            f'Being {words[k-1]} means {k - 1} {"person is" if k - 1 == 1 else "people are"} in front.')


def t_pattern(ctx):
    unit = ctx.rnd.choice([['red', 'blue'], ['circle', 'square', 'triangle'],
                           ['A', 'B', 'B'], ['1', '2', '3']])
    reps = 3
    seq = (unit * reps)[:len(unit) * reps]
    nxt = unit[len(seq) % len(unit)]
    wrong = [u for u in unit if u != nxt]
    return (f'What comes next in this pattern? {", ".join(seq)}, ?', nxt,
            wrong + ['none of these'], 'Find the part that repeats.',
            f'The pattern repeats {", ".join(unit)}, so next comes {nxt}.')


def t_money_simple(ctx):
    hi = band(ctx, 10, 50, 100)
    a, b = ctx.rnd.randint(1, hi), ctx.rnd.randint(1, hi)
    nm = ctx.name()
    return (f'{nm} has {ctx.money(a)} and is given {ctx.money(b)} more. How much does {nm} have now?',
            ctx.money(a + b),
            [ctx.money(abs(a - b)), ctx.money(a + b + 1), ctx.money(a + b - 1)],
            'Put the two amounts together.',
            f'{a} + {b} = {a + b}, so {nm} has {ctx.money(a + b)}.')


def t_money_change(ctx):
    hi = band(ctx, 20, 100, 500)
    paid = ctx.rnd.choice([x for x in (20, 50, 100, 200, 500) if x <= hi * 2])
    cost = ctx.rnd.randint(1, paid - 1)
    nm = ctx.name()
    return (f'{nm} buys a book for {ctx.money(cost)} and pays with {ctx.money(paid)}. '
            f'How much change is given?',
            ctx.money(paid - cost),
            [ctx.money(paid + cost), ctx.money(paid - cost + 1), ctx.money(cost)],
            'Take the cost away from what was handed over.',
            f'{paid} − {cost} = {paid - cost}, so the change is {ctx.money(paid - cost)}.')


def t_time_oclock(ctx):
    h = ctx.rnd.randint(1, 12); add = ctx.rnd.randint(1, band(ctx, 3, 6, 11))
    end = (h + add - 1) % 12 + 1
    return (f"A lesson starts at {h} o'clock and lasts {add} hour{'s' if add > 1 else ''}. "
            f'What time does it finish?',
            f"{end} o'clock",
            [f"{(h + add) % 12 + 1} o'clock", f"{(h - add - 1) % 12 + 1} o'clock",
             f"{h} o'clock"],
            'Count the hours forward from the start.',
            f'{h} + {add} = {h + add}, which on a clock face is {end} o\'clock.')


def t_time_half(ctx):
    h = ctx.rnd.randint(1, 12); half = ctx.rnd.choice([0, 30])
    add = ctx.rnd.choice([30, 60, 90] if ctx.difficulty != 'easy' else [30, 60])
    total = h * 60 + half + add
    eh = (total // 60 - 1) % 12 + 1; em = total % 60
    start = f'{h}:{half:02d}'
    return (f'A film starts at {start} and lasts {add} minutes. When does it end?',
            f'{eh}:{em:02d}',
            [f'{eh}:{(em + 30) % 60:02d}', f'{(eh % 12) + 1}:{em:02d}', f'{h}:{(half + add) % 60:02d}'],
            'Add the minutes first, then any whole hours.',
            f'{start} plus {add} minutes is {eh}:{em:02d}.')


def t_place_value(ctx):
    digits = band(ctx, 3, 4, 5)
    n = ctx.rnd.randint(10 ** (digits - 1), 10 ** digits - 1)
    pos = ctx.rnd.randint(0, digits - 1)              # 0 = ones
    names = ['ones', 'tens', 'hundreds', 'thousands', 'ten thousands']
    d = (n // 10 ** pos) % 10
    return (f'In the number {n}, what is the digit in the {names[pos]} place?',
            d, [(d + 1) % 10, (d + 2) % 10, n % 10 if n % 10 != d else (d + 3) % 10],
            'Count the places from the right.',
            f'Reading {n} from the right, the {names[pos]} digit is {d}.')


def t_add_regroup(ctx):
    lo, hi = band(ctx, (10, 99), (100, 499), (100, 999))
    a, b = ctx.rnd.randint(lo, hi), ctx.rnd.randint(lo, hi)
    # the classic mistake: adding each column and forgetting to carry
    no_carry = sum(((a // 10 ** k % 10) + (b // 10 ** k % 10)) % 10 * 10 ** k for k in range(4))
    return (f'{a} + {b} = ?', a + b,
            [no_carry, a + b - 10, a + b + 10],
            'Add the ones first and carry into the tens if you go past 9.',
            f'{a} + {b} = {a + b}.')


def t_sub_regroup(ctx):
    lo, hi = band(ctx, (10, 99), (100, 499), (100, 999))
    a = ctx.rnd.randint(lo, hi); b = ctx.rnd.randint(lo, a)
    # the classic mistake: taking the smaller digit from the larger in each column
    cols = ''.join(str(abs((a // 10 ** k % 10) - (b // 10 ** k % 10))) for k in range(3))[::-1]
    flip = int(cols)
    return (f'{a} − {b} = ?', a - b,
            [flip if flip != a - b else a - b + 10, a + b, a - b - 10],
            'If the top digit is too small, borrow from the next column.',
            f'{a} − {b} = {a - b}.')


def t_times_easy(ctx):
    t = ctx.rnd.choice([2, 5, 10] if ctx.difficulty == 'easy' else [2, 3, 4, 5, 10])
    k = ctx.rnd.randint(1, band(ctx, 5, 10, 12))
    return (f'{t} × {k} = ?', t * k,
            [t * k + t, t * k - t, t + k],                  # off by one group, and added instead
            f'{t} × {k} means {k} lots of {t}.',
            f'{t} × {k} = {t * k}.')


def t_times_table(ctx):
    a = ctx.rnd.randint(2, band(ctx, 5, 9, 12)); b = ctx.rnd.randint(2, band(ctx, 5, 9, 12))
    return (f'{a} × {b} = ?', a * b,
            [a * b + a, a * b - b, a + b],
            f'Count in {a}s, {b} times.',
            f'{a} × {b} = {a * b}.')


def t_divide_simple(ctx):
    b = ctx.rnd.randint(2, band(ctx, 5, 9, 12)); q = ctx.rnd.randint(2, band(ctx, 5, 10, 12))
    a = b * q
    return (f'{a} ÷ {b} = ?', q,
            [q + 1, q - 1, a - b],
            f'How many {b}s fit into {a}?',
            f'{b} × {q} = {a}, so {a} ÷ {b} = {q}.')


def t_divide_remainder(ctx):
    b = ctx.rnd.randint(3, band(ctx, 6, 9, 12))
    q = ctx.rnd.randint(2, band(ctx, 9, 20, 40)); r = ctx.rnd.randint(1, b - 1)
    a = b * q + r
    nm = ctx.name()
    return (f'{nm} shares {a} stickers equally among {b} friends. How many are left over?',
            r, [(r + 1) % b, q, b - r],
            'Divide, then look at what will not go round again.',
            f'{a} ÷ {b} = {q} remainder {r}, so {r} sticker{"s are" if r != 1 else " is"} left.')


def t_fractions_unit(ctx):
    d = ctx.rnd.choice([2, 3, 4] if ctx.difficulty == 'easy' else [2, 3, 4, 5, 6, 8, 10])
    whole = d * ctx.rnd.randint(2, band(ctx, 4, 8, 12))
    return (f'What is 1/{d} of {whole}?', whole // d,
            [whole * d, whole - d, whole // d + 1],
            f'Split {whole} into {d} equal parts.',
            f'{whole} ÷ {d} = {whole // d}.')


def t_half_quarter(ctx):
    d = ctx.rnd.choice([2, 4])
    whole = d * ctx.rnd.randint(1, band(ctx, 5, 10, 20))
    word = 'half' if d == 2 else 'a quarter'
    return (f'What is {word} of {whole}?', whole // d,
            [whole * d, whole // d + 1, whole - d],
            f'Share {whole} into {d} equal groups.',
            f'{whole} ÷ {d} = {whole // d}.')


def t_fractions_equiv(ctx):
    n = ctx.rnd.randint(1, 5); d = ctx.rnd.randint(n + 1, 10)
    k = ctx.rnd.randint(2, band(ctx, 3, 5, 8))
    return (f'Which fraction is equal to {n}/{d}?', f'{n*k}/{d*k}',
            [f'{n+k}/{d+k}', f'{n*k}/{d}', f'{n}/{d*k}'],   # added instead of multiplied; one side only
            'Multiply the top and the bottom by the same number.',
            f'{n}/{d} × {k}/{k} = {n*k}/{d*k}. Multiplying both by {k} does not change the value.')


def t_fractions_ops(ctx):
    d = ctx.rnd.choice([4, 6, 8, 10, 12])
    a = ctx.rnd.randint(1, d - 1); b = ctx.rnd.randint(1, d - a)
    from math import gcd
    num, den = a + b, d
    g = gcd(num, den)
    ans = f'{num//g}/{den//g}' if den // g != 1 else str(num // g)
    return (f'{a}/{d} + {b}/{d} = ?', ans,
            [f'{a+b}/{d+d}', f'{a*b}/{d}', f'{a+b+1}/{d}'],
            'The bottoms are the same, so just add the tops.',
            f'{a}/{d} + {b}/{d} = {num}/{den}' + (f', which simplifies to {ans}.' if g > 1 else '.'))


def t_decimals_intro(ctx):
    whole = ctx.rnd.randint(0, band(ctx, 5, 20, 50)); tenth = ctx.rnd.randint(1, 9)
    return (f'Write {whole} and {tenth} tenths as a decimal.', f'{whole}.{tenth}',
            [f'{whole}.0{tenth}', f'{tenth}.{whole}', f'{whole}{tenth}'],
            'Tenths go in the first place after the point.',
            f'{whole} and {tenth} tenths is written {whole}.{tenth}.')


def t_decimals_ops(ctx):
    a = round(ctx.rnd.uniform(1, band(ctx, 10, 50, 100)), 2)
    b = round(ctx.rnd.uniform(1, band(ctx, 10, 50, 100)), 2)
    s = round(a + b, 2)
    return (f'{a} + {b} = ?', f'{s:g}',
            [f'{round(a + b + 0.1, 2):g}', f'{round(abs(a - b), 2):g}', f'{round(a * b, 2):g}'],
            'Line up the decimal points before you add.',
            f'{a} + {b} = {s:g}.')


def t_percent_intro(ctx):
    pct = ctx.rnd.choice([10, 20, 25, 50] if ctx.difficulty == 'easy' else [5, 10, 15, 20, 25, 40, 50, 75])
    for base in ctx.rnd.sample([20, 40, 60, 80, 100, 200, 400, 500, 800], 9):
        if (base * pct) % 100 == 0: break
    else:
        return None
    ans = base * pct // 100
    return (f'What is {pct}% of {base}?', ans,
            [base * pct // 10 if base * pct % 10 == 0 else ans * 10, ans + pct, base - ans],
            f'{pct}% means {pct} out of every 100.',
            f'{pct}% of {base} = {base} × {pct}/100 = {ans}.')


def t_percent(ctx):
    return t_percent_intro(ctx)


def t_measure_len(ctx):
    if ctx.cfg['unit'] == 'customary':
        big, small, per = 'foot', 'inches', 12
    else:
        big, small, per = 'metre' if ctx.cfg['spell'] != 'en-US' else 'meter', 'centimetres', 100
        if ctx.cfg['spell'] == 'en-US': small = 'centimeters'
    n = ctx.rnd.randint(1, band(ctx, 4, 9, 20))
    return (f'How many {small} are there in {n} {big}{"s" if n > 1 else ""}?', n * per,
            [n * per // 10, n + per, n * per * 10],
            f'One {big} is {per} {small}.',
            f'{n} × {per} = {n * per}.')


def t_perimeter(ctx):
    w = ctx.rnd.randint(2, band(ctx, 9, 20, 40)); h = ctx.rnd.randint(2, band(ctx, 9, 20, 40))
    unit = 'cm' if ctx.cfg['unit'] == 'metric' else 'in'
    return (f'A rectangle is {w} {unit} long and {h} {unit} wide. What is its perimeter?',
            f'{2*(w+h)} {unit}',
            [f'{w*h} {unit}', f'{w+h} {unit}', f'{2*w*h} {unit}'],   # area instead; one pair only
            'Add all four sides.',
            f'2 × ({w} + {h}) = {2*(w+h)} {unit}.')


def t_area_rect(ctx):
    w = ctx.rnd.randint(2, band(ctx, 9, 20, 40)); h = ctx.rnd.randint(2, band(ctx, 9, 20, 40))
    unit = 'cm' if ctx.cfg['unit'] == 'metric' else 'in'
    return (f'A rectangle is {w} {unit} by {h} {unit}. What is its area?',
            f'{w*h} {unit}²',
            [f'{2*(w+h)} {unit}²', f'{w+h} {unit}²', f'{w*h*2} {unit}²'],
            'Area is length times width.',
            f'{w} × {h} = {w*h} {unit}².')


def t_area_triangle(ctx):
    b = ctx.rnd.choice([2, 4, 6, 8, 10, 12, 14, 16]); h = ctx.rnd.randint(2, band(ctx, 8, 15, 25))
    unit = 'cm' if ctx.cfg['unit'] == 'metric' else 'in'
    return (f'A triangle has a base of {b} {unit} and a height of {h} {unit}. What is its area?',
            f'{b*h//2} {unit}²',
            [f'{b*h} {unit}²', f'{b+h} {unit}²', f'{(b+h)//2} {unit}²'],  # forgot the half
            'Half of base times height.',
            f'½ × {b} × {h} = {b*h//2} {unit}².')


def t_volume_cuboid(ctx):
    a, b, c = (ctx.rnd.randint(2, band(ctx, 5, 9, 15)) for _ in range(3))
    unit = 'cm' if ctx.cfg['unit'] == 'metric' else 'in'
    return (f'A box measures {a} {unit} × {b} {unit} × {c} {unit}. What is its volume?',
            f'{a*b*c} {unit}³',
            [f'{a+b+c} {unit}³', f'{2*(a*b+b*c+a*c)} {unit}³', f'{a*b} {unit}³'],
            'Multiply all three measurements.',
            f'{a} × {b} × {c} = {a*b*c} {unit}³.')


def t_average(ctx):
    n = ctx.rnd.choice([3, 4, 5])
    vals = [ctx.rnd.randint(1, band(ctx, 20, 50, 100)) for _ in range(n)]
    tot = sum(vals)
    vals[0] += (n - tot % n) % n           # keep the mean whole
    tot = sum(vals)
    return (f'What is the average of {", ".join(map(str, vals))}?', tot // n,
            [tot, tot // n + 1, max(vals)],
            'Add them all, then divide by how many there are.',
            f'({" + ".join(map(str, vals))}) ÷ {n} = {tot} ÷ {n} = {tot // n}.')


def t_mean(ctx): return t_average(ctx)


def t_large_numbers(ctx):
    n = ctx.rnd.randint(10 ** 5, 10 ** band(ctx, 6, 7, 8) - 1)
    return (f'What is the place value of the digit {str(n)[0]} in {n:,}?',
            10 ** (len(str(n)) - 1),
            [10 ** (len(str(n)) - 2), int(str(n)[0]), 10 ** len(str(n))],
            'Count how many places it is from the right.',
            f'The first digit of {n:,} sits in the {10 ** (len(str(n)) - 1)} place '
            f'({10 ** (len(str(n)) - 1):,}).')


def t_factors(ctx):
    n = ctx.rnd.choice([12, 18, 20, 24, 30, 36, 40, 48, 60])
    facs = [k for k in range(1, n + 1) if n % k == 0]
    non = ctx.rnd.choice([k for k in range(2, n) if n % k])
    return (f'Which of these is a factor of {n}?', ctx.rnd.choice(facs[1:-1]),
            [non, non + 1 if n % (non + 1) else non + 2, n + 1],
            'A factor divides it exactly, with nothing left over.',
            f'The factors of {n} are {", ".join(map(str, facs))}.')


def t_primes(ctx):
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    comps = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20, 21, 22, 24, 25, 26, 27, 28]
    p = ctx.rnd.choice(primes)
    return ('Which of these is a prime number?', p,
            ctx.rnd.sample(comps, 3),
            'A prime has exactly two factors: 1 and itself.',
            f'{p} can only be divided by 1 and {p}, so it is prime.')


def t_hcf_lcm(ctx):
    from math import gcd
    a = ctx.rnd.randint(4, band(ctx, 20, 40, 80)); b = ctx.rnd.randint(4, band(ctx, 20, 40, 80))
    which = ctx.rnd.choice(['HCF', 'LCM'])
    g = gcd(a, b); l = a * b // g
    if which == 'HCF':
        return (f'What is the highest common factor of {a} and {b}?', g,
                [l, min(a, b), g * 2 if g * 2 != l else g + 1],
                'Find the biggest number that divides both.',
                f'The HCF of {a} and {b} is {g}.')
    return (f'What is the lowest common multiple of {a} and {b}?', l,
            [g, a * b, max(a, b)],
            'Find the smallest number both divide into.',
            f'The LCM of {a} and {b} is {l}.')


def t_integers(ctx):
    a = ctx.rnd.randint(-band(ctx, 10, 30, 60), band(ctx, 10, 30, 60))
    b = ctx.rnd.randint(-band(ctx, 10, 30, 60), band(ctx, 10, 30, 60))
    return (f'({a}) + ({b}) = ?', a + b,
            [a - b, abs(a) + abs(b), -(a + b) if a + b else a + b + 1],
            'On a number line, a negative number moves you left.',
            f'({a}) + ({b}) = {a + b}.')


def t_integers_ops(ctx):
    a = ctx.rnd.randint(-band(ctx, 9, 20, 40), band(ctx, 9, 20, 40))
    b = ctx.rnd.randint(-band(ctx, 9, 12, 20), band(ctx, 9, 12, 20))
    while b == 0: b = ctx.rnd.randint(-9, 9)
    return (f'({a}) × ({b}) = ?', a * b,
            [-(a * b) if a * b else 1, a + b, abs(a * b) if a * b < 0 else -abs(a * b)],
            'Two negatives multiply to a positive.',
            f'({a}) × ({b}) = {a * b}.')


def t_rational(ctx):
    from math import gcd
    d1 = ctx.rnd.choice([2, 3, 4, 5, 6]); d2 = ctx.rnd.choice([2, 3, 4, 5, 6])
    n1 = ctx.rnd.randint(1, d1); n2 = ctx.rnd.randint(1, d2)
    num, den = n1 * d2 + n2 * d1, d1 * d2
    g = gcd(num, den)
    ans = f'{num//g}/{den//g}' if den // g != 1 else str(num // g)
    return (f'{n1}/{d1} + {n2}/{d2} = ?', ans,
            [f'{n1+n2}/{d1+d2}', f'{n1*n2}/{d1*d2}', f'{num}/{den}' if g > 1 else f'{num+1}/{den}'],
            'Make the bottoms the same first.',
            f'{n1}/{d1} + {n2}/{d2} = {num}/{den}' + (f' = {ans}.' if g > 1 else '.'))


def t_algebra_intro(ctx):
    a = ctx.rnd.randint(2, band(ctx, 6, 12, 20)); x = ctx.rnd.randint(1, band(ctx, 9, 15, 25))
    b = a * x
    return (f'If {a}x = {b}, what is x?', x,
            [b, b - a, x + 1],
            f'What times {a} gives {b}?',
            f'{b} ÷ {a} = {x}.')


def t_equation_simple(ctx):
    a = ctx.rnd.randint(2, band(ctx, 5, 9, 12)); x = ctx.rnd.randint(1, band(ctx, 9, 15, 25))
    c = ctx.rnd.randint(1, band(ctx, 10, 30, 60))
    b = a * x + c
    return (f'Solve for x: {a}x + {c} = {b}', x,
            [b - c, x + 1, (b + c) // a],
            f'Take {c} from both sides first.',
            f'{a}x = {b} − {c} = {b - c}, so x = {b - c} ÷ {a} = {x}.')


def t_linear_equation(ctx):
    a = ctx.rnd.randint(2, 9); b = ctx.rnd.randint(1, 9)
    x = ctx.rnd.randint(1, band(ctx, 9, 15, 25))
    c = ctx.rnd.randint(1, 9); d = a * x + b - c * x
    return (f'Solve for x: {a}x + {b} = {c}x + {d}', x,
            [x + 1, d - b, (d + b) // max(1, a - c) if a != c else x + 2],
            'Get all the x terms on one side and the numbers on the other.',
            f'{a}x − {c}x = {d} − {b}, so {a - c}x = {d - b} and x = {x}.')


def t_exponents(ctx):
    b = ctx.rnd.randint(2, band(ctx, 5, 8, 12)); e = ctx.rnd.randint(2, band(ctx, 3, 4, 5))
    return (f'What is {b}^{e}?', b ** e,
            [b * e, b ** (e - 1), b ** (e + 1)],           # multiplied instead of powered
            f'{b}^{e} means {b} multiplied by itself {e} times.',
            f'{" × ".join([str(b)] * e)} = {b ** e}.')


def t_squares_roots(ctx):
    n = ctx.rnd.randint(2, band(ctx, 12, 20, 30))
    if ctx.rnd.random() < .5:
        return (f'What is {n}²?', n * n, [n * 2, n * n + n, (n + 1) ** 2],
                f'{n}² means {n} × {n}.', f'{n} × {n} = {n * n}.')
    return (f'What is the square root of {n * n}?', n, [n * n // 2, n + 1, n * 2],
            'Which number times itself gives it?', f'{n} × {n} = {n * n}, so √{n * n} = {n}.')


def t_roman(ctx):
    vals = [(1, 'I'), (4, 'IV'), (5, 'V'), (9, 'IX'), (10, 'X'), (40, 'XL'),
            (50, 'L'), (90, 'XC'), (100, 'C')]
    def to_roman(n):
        out = ''
        for v, s in sorted(vals, reverse=True):
            while n >= v: out += s; n -= v
        return out
    n = ctx.rnd.randint(1, band(ctx, 20, 50, 100))
    r = to_roman(n)
    return (f'What is {n} in Roman numerals?', r,
            [to_roman(n + 1), to_roman(max(1, n - 1)), to_roman(n) + 'I'],
            'Build it from the largest symbols down.',
            f'{n} is written {r}.')


def t_angles_kind(ctx):
    kinds = [('acute', (10, 89)), ('right', (90, 90)), ('obtuse', (91, 179)),
             ('straight', (180, 180)), ('reflex', (181, 350))]
    if ctx.difficulty == 'easy': kinds = kinds[:3]
    nm, (lo, hi) = ctx.rnd.choice(kinds)
    a = ctx.rnd.randint(lo, hi)
    others = [k for k, _ in kinds if k != nm]
    return (f'An angle measures {a}°. What kind of angle is it?', nm,
            ctx.rnd.sample(others, 3) if len(others) >= 3 else others + ['none of these'],
            'Compare it with 90° and 180°.',
            f'{a}° is {"exactly " if lo == hi else ""}{nm}.')


def t_angles_triangle(ctx):
    a = ctx.rnd.randint(20, 100); b = ctx.rnd.randint(20, 170 - a)
    c = 180 - a - b
    return (f'Two angles of a triangle are {a}° and {b}°. What is the third?', f'{c}°',
            [f'{180 - a}°', f'{a + b}°', f'{360 - a - b}°'],   # forgot one; used 360
            'The three angles of a triangle add to 180°.',
            f'180 − {a} − {b} = {c}°.')


def t_ratio(ctx):
    from math import gcd
    k = ctx.rnd.randint(2, band(ctx, 4, 8, 12))
    a, b = ctx.rnd.randint(1, 6), ctx.rnd.randint(1, 6)
    g = gcd(a, b); a, b = a // g, b // g
    total = (a + b) * k
    nm1, nm2 = ctx.two_names()
    return (f'{nm1} and {nm2} share {total} marbles in the ratio {a}:{b}. '
            f'How many does {nm1} get?',
            a * k, [b * k, total // 2, total - a * k if total - a * k != b * k else a * k + 1],
            f'There are {a + b} shares altogether.',
            f'{total} ÷ {a + b} = {k} per share, so {nm1} gets {a} × {k} = {a * k}.')


def t_proportion(ctx):
    a = ctx.rnd.randint(2, 9); cost = a * ctx.rnd.randint(2, band(ctx, 10, 25, 50))
    b = ctx.rnd.randint(2, 12)
    per = cost // a
    return (f'{a} notebooks cost {ctx.money(cost)}. How much do {b} notebooks cost?',
            ctx.money(per * b),
            [ctx.money(cost * b), ctx.money(per), ctx.money(cost + b)],
            'Find the cost of one first.',
            f'One costs {ctx.money(per)}, so {b} cost {per} × {b} = {ctx.money(per * b)}.')


def t_profit_loss(ctx):
    """Cost prices are chosen so the percentage lands exactly.

       It did not, in the first build: ₹250 at 25% gave a gain of ₹62 rather
       than ₹62.50, because the code divided with // and threw the half away.
       The bank then confidently offered ₹312 for a question whose answer is
       ₹312.50. Nothing caught it — the checker could not parse profit and
       loss, so it counted the question as unverified and moved on, which is
       exactly the hole an unverified question hides in."""
    pct = ctx.rnd.choice([5, 10, 20, 25, 50])
    for cp in ctx.rnd.sample([100, 200, 300, 400, 500, 600, 800, 1000, 1200, 1600], 10):
        if (cp * pct) % 100 == 0: break
    else:
        return None
    gain = cp * pct // 100
    up = ctx.rnd.random() < .5
    sp = cp + gain if up else cp - gain
    word = 'profit' if up else 'loss'
    return (f'An item bought for {ctx.money(cp)} is sold at a {pct}% {word}. '
            f'What is the selling price?',
            ctx.money(sp),
            [ctx.money(cp - gain if up else cp + gain), ctx.money(cp), ctx.money(gain)],
            f'Work out {pct}% of the cost price first.',
            f'{pct}% of {cp} is {gain}, so the selling price is {cp} {"+" if up else "−"} {gain} = {ctx.money(sp)}.')


def t_compare_quantities(ctx): return t_profit_loss(ctx)


def t_interest(ctx):
    r = ctx.rnd.choice([4, 5, 8, 10]); t = ctx.rnd.randint(1, 4)
    for p in ctx.rnd.sample([1000, 2000, 2500, 4000, 5000, 8000], 6):
        if (p * r * t) % 100 == 0: break
    else:
        return None
    si = p * r * t // 100
    return (f'Find the simple interest on {ctx.money(p)} at {r}% per year for {t} year'
            f'{"s" if t > 1 else ""}.',
            ctx.money(si),
            [ctx.money(p * r // 100), ctx.money(si * 2), ctx.money(p + si)],
            'Simple interest is principal × rate × time ÷ 100.',
            f'({p} × {r} × {t}) ÷ 100 = {ctx.money(si)}.')


def t_algebra_identity(ctx):
    a = ctx.rnd.randint(1, 9); b = ctx.rnd.randint(1, 9)
    return (f'Expand (x + {a})(x + {b}).',
            f'x² + {a+b}x + {a*b}',
            [f'x² + {a*b}x + {a+b}', f'x² + {a+b}x + {a+b}', f'x² + {a*b}'],
            'Multiply every term in the first bracket by every term in the second.',
            f'x·x + {a}x + {b}x + {a}·{b} = x² + {a+b}x + {a*b}.')


def t_factorise(ctx):
    a = ctx.rnd.randint(2, 9); b = ctx.rnd.randint(2, 9)
    return (f'Factorise x² + {a+b}x + {a*b}.',
            f'(x + {a})(x + {b})',
            [f'(x + {a+b})(x + {a*b})', f'(x − {a})(x − {b})', f'(x + {a})(x − {b})'],
            'Find two numbers that multiply to the last term and add to the middle one.',
            f'{a} × {b} = {a*b} and {a} + {b} = {a+b}, so it factorises as (x + {a})(x + {b}).')


def t_mensuration_cyl(ctx):
    r = ctx.rnd.choice([7, 14, 21]); h = ctx.rnd.randint(5, 30)
    vol = 22 * r * r * h // 7
    unit = 'cm' if ctx.cfg['unit'] == 'metric' else 'in'
    return (f'A cylinder has radius {r} {unit} and height {h} {unit}. '
            f'What is its volume? (Take π = 22/7)',
            f'{vol} {unit}³',
            [f'{22 * r * h // 7} {unit}³', f'{vol * 2} {unit}³', f'{r * r * h} {unit}³'],
            'Volume of a cylinder is πr²h.',
            f'(22/7) × {r}² × {h} = {vol} {unit}³.')


def t_time_min(ctx):
    h = ctx.rnd.randint(1, 11)
    m1 = ctx.rnd.choice([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55])
    add = ctx.rnd.choice([15, 20, 25, 40, 45, 50] if ctx.difficulty != 'easy' else [15, 30, 45])
    total = h * 60 + m1 + add
    eh = (total // 60 - 1) % 12 + 1; em = total % 60
    return (f'The bell rings at {h}:{m1:02d}. Break lasts {add} minutes. When does it end?',
            f'{eh}:{em:02d}',
            [f'{h}:{(m1 + add) % 60:02d}',              # forgot to roll into the next hour
             f'{eh}:{(em + 5) % 60:02d}',
             f'{(eh % 12) + 1}:{em:02d}'],
            'Add the minutes, and roll over into the next hour past 60.',
            f'{m1} + {add} = {m1 + add} minutes, which is {eh}:{em:02d}.')


def t_multiply_2d(ctx):
    a = ctx.rnd.randint(11, band(ctx, 25, 60, 99))
    b = ctx.rnd.randint(2, band(ctx, 9, 15, 40))
    # the classic mistake: multiplying the tens and the ones separately and
    # adding, without the cross terms
    naive = (a // 10 * 10) * (b // 10 * 10 if b >= 10 else b) + (a % 10) * (b % 10)
    return (f'{a} × {b} = ?', a * b,
            [naive if naive != a * b else a * b + 10, a + b, a * b - a],
            f'Split {a} into tens and ones, multiply each, then add.',
            f'{a} × {b} = {a * b}.')


def t_data_pict(ctx):
    each = ctx.rnd.choice([2, 5, 10])
    syms = ctx.rnd.randint(2, band(ctx, 5, 8, 12))
    thing = ctx.rnd.choice(['books', 'apples', 'cars', 'trees', 'birds'])
    return (f'On a picture graph, each symbol stands for {each} {thing}. '
            f'How many {thing} do {syms} symbols show?',
            each * syms,
            [each + syms, each * syms // 2 if each * syms % 2 == 0 else each * syms + 1, syms],
            f'Each symbol is worth {each}.',
            f'{syms} × {each} = {each * syms}.')




# ════════════════════════════════════════════════════════════════════
#  Multi-step questions, for the top of each grade.
#
#  The first build's "hard" was the same single step with bigger numbers,
#  which is not what hard means to a thirteen-year-old — 20% of 40 is a
#  grade 5 warm-up whatever band it is filed under. These need two or three
#  moves and, more importantly, a decision about which move comes first.
# ════════════════════════════════════════════════════════════════════

def t_ms_shopping(ctx):
    """Buy several things, apply a discount, work out what is paid.

       The numbers are searched for rather than adjusted afterwards. The
       first version nudged the subtotal until the percentage divided
       exactly — but it nudged it *after* printing the prices, so the
       question said one thing and the answer meant another."""
    pct = ctx.rnd.choice([10, 20, 25, 50])
    for _ in range(60):
        n1, n2 = ctx.rnd.randint(2, 6), ctx.rnd.randint(2, 5)
        p1 = ctx.rnd.choice([20, 25, 40, 50, 60]); p2 = ctx.rnd.choice([15, 30, 45, 80])
        sub = n1 * p1 + n2 * p2
        if (sub * pct) % 100 == 0: break
    else:
        return None
    disc = sub * pct // 100
    pay = sub - disc
    nm = ctx.name()
    return (f'{nm} buys {n1} notebooks at {ctx.money(p1)} each and {n2} pens at '
            f'{ctx.money(p2)} each. A {pct}% discount is given on the total. '
            f'How much does {nm} pay?',
            ctx.money(pay),
            [ctx.money(sub), ctx.money(disc), ctx.money(sub + disc)],
            'Find the total first, then take the discount off it.',
            f'{n1} × {p1} + {n2} × {p2} = {sub}. A {pct}% discount is {disc}, '
            f'so the amount paid is {ctx.money(pay)}.')


def t_ms_speed(ctx):
    """Distance, speed and time, with one of the three missing."""
    sp = ctx.rnd.choice([40, 50, 60, 80]); t = ctx.rnd.choice([2, 3, 4, 5])
    d = sp * t
    unit = 'km' if ctx.cfg['unit'] == 'metric' else 'miles'
    which = ctx.rnd.choice(['time', 'speed'])
    if which == 'time':
        return (f'A train travels {d} {unit} at a steady {sp} {unit} per hour. '
                f'How long does the journey take?',
                f'{t} hours', [f'{t + 1} hours', f'{d // (t or 1)} hours', f'{sp} hours'],
                'Time is distance divided by speed.',
                f'{d} ÷ {sp} = {t} hours.')
    return (f'A car covers {d} {unit} in {t} hours. What is its average speed?',
            f'{sp} {unit} per hour',
            [f'{d} {unit} per hour', f'{t} {unit} per hour', f'{sp * t} {unit} per hour'],
            'Speed is distance divided by time.',
            f'{d} ÷ {t} = {sp} {unit} per hour.')


def t_ms_fraction_remainder(ctx):
    """Spend a fraction, then a fraction of what is left."""
    d1 = ctx.rnd.choice([2, 3, 4, 5]); d2 = ctx.rnd.choice([2, 3, 4])
    total = d1 * d2 * ctx.rnd.randint(2, 9)
    spent = total // d1
    left = total - spent
    second = left // d2
    final = left - second
    nm = ctx.name()
    return (f'{nm} had {ctx.money(total)}. She spent 1/{d1} of it on books and '
            f'1/{d2} of what was left on food. How much is left now?',
            ctx.money(final),
            [ctx.money(left), ctx.money(total - spent - second - 1), ctx.money(second)],
            'Work out what is left after the books before you touch the food.',
            f'Books: {total} ÷ {d1} = {spent}, leaving {left}. '
            f'Food: {left} ÷ {d2} = {second}, leaving {ctx.money(final)}.')


def t_ms_average_missing(ctx):
    """The mean is given; one value is not."""
    n = ctx.rnd.choice([4, 5]); mean = ctx.rnd.randint(20, 80)
    vals = [ctx.rnd.randint(10, 95) for _ in range(n - 1)]
    missing = mean * n - sum(vals)
    while missing < 1 or missing > 100:
        vals = [ctx.rnd.randint(10, 95) for _ in range(n - 1)]
        missing = mean * n - sum(vals)
    return (f'The average of {n} numbers is {mean}. {n - 1} of them are '
            f'{", ".join(map(str, vals))}. What is the last number?',
            missing,
            [mean, mean * n, abs(mean - sum(vals) // (n - 1))],
            'The total of all of them must be the average times how many there are.',
            f'The total must be {mean} × {n} = {mean * n}. '
            f'{mean * n} − {sum(vals)} = {missing}.')


def t_ms_percent_change(ctx):
    """Up by one percentage, then down by another — the classic trap where
       the two do not cancel."""
    up = ctx.rnd.choice([10, 20, 25]); down = ctx.rnd.choice([10, 20, 25])
    for base in ctx.rnd.sample([200, 400, 500, 800, 1000, 1200, 1600, 2000], 8):
        if (base * up) % 100: continue
        after_up = base + base * up // 100
        if (after_up * down) % 100 == 0: break
    else:
        return None
    final = after_up - after_up * down // 100
    return (f'The price of a phone is {ctx.money(base)}. It rises by {up}% and then '
            f'falls by {down}%. What is the final price?',
            ctx.money(final),
            [ctx.money(base), ctx.money(after_up),
             ctx.money(base + base * (up - down) // 100)],
            'The second percentage is taken from the new price, not the old one.',
            f'After the rise: {ctx.money(after_up)}. A {down}% fall on that is '
            f'{after_up * down // 100}, giving {ctx.money(final)}. '
            f'It does not return to {ctx.money(base)} because the {down}% is taken '
            f'from the larger amount.')


def t_ms_ratio_difference(ctx):
    """Ratio given, plus the difference rather than the total."""
    a, b = ctx.rnd.choice([(2, 3), (3, 5), (4, 7), (5, 8), (2, 5)])
    k = ctx.rnd.randint(3, 15)
    diff = (b - a) * k
    nm1, nm2 = ctx.two_names()
    return (f'{nm1} and {nm2} share money in the ratio {a}:{b}. '
            f'{nm2} gets {ctx.money(diff)} more than {nm1}. How much is shared altogether?',
            ctx.money((a + b) * k),
            [ctx.money(diff), ctx.money(a * k), ctx.money((b - a) * k * 2)],
            'The difference is worth b − a shares.',
            f'The difference of {b - a} shares is {diff}, so one share is {k}. '
            f'Altogether {a + b} shares = {ctx.money((a + b) * k)}.')


def t_ms_compound_interest(ctx):
    """Two years of compound interest, and the gap against simple."""
    r = ctx.rnd.choice([5, 10, 20])
    for p in ctx.rnd.sample([1000, 2000, 4000, 5000, 8000, 10000, 12000, 16000], 8):
        if (p * r) % 100: continue
        y1 = p * r // 100
        a1 = p + y1
        if (a1 * r) % 100 == 0: break
    else:
        return None
    y2 = a1 * r // 100
    total = y1 + y2
    si = 2 * p * r // 100
    return (f'Find the compound interest on {ctx.money(p)} at {r}% per year for 2 years.',
            ctx.money(total),
            [ctx.money(si), ctx.money(y1), ctx.money(p + total)],
            'The second year earns interest on the first year\'s interest too.',
            f'Year 1: {ctx.money(y1)}. The amount becomes {ctx.money(a1)}. '
            f'Year 2: {ctx.money(y2)}. Total interest {ctx.money(total)} — '
            f'{ctx.money(total - si)} more than simple interest.')


def t_ms_algebra_word(ctx):
    """A sentence that has to become an equation before it can be solved."""
    x = ctx.rnd.randint(4, 30); k = ctx.rnd.randint(2, 6); c = ctx.rnd.randint(3, 20)
    total = k * x + c
    nm = ctx.name()
    return (f'{nm} thinks of a number, multiplies it by {k} and adds {c}. '
            f'The result is {total}. What was the number?',
            x, [total - c, total // k, x + k],
            'Undo the steps in the opposite order.',
            f'{total} − {c} = {k * x}, and {k * x} ÷ {k} = {x}.')


def t_ms_area_path(ctx):
    """Composite area: a lawn with a path around it."""
    w = ctx.rnd.choice([10, 12, 15, 20, 24]); h = ctx.rnd.choice([8, 10, 14, 18])
    p = ctx.rnd.choice([1, 2, 3])
    unit = 'm'
    outer = (w + 2 * p) * (h + 2 * p)
    inner = w * h
    return (f'A garden is {w} {unit} by {h} {unit}. A path {p} {unit} wide runs all '
            f'the way around the outside. What is the area of the path?',
            f'{outer - inner} {unit}²',
            [f'{inner} {unit}²', f'{outer} {unit}²', f'{2 * p * (w + h)} {unit}²'],
            'Find the big rectangle and take the garden out of it.',
            f'Outer: {w + 2*p} × {h + 2*p} = {outer}. Garden: {inner}. '
            f'Path: {outer} − {inner} = {outer - inner} {unit}².')


def t_ms_work_rate(ctx):
    """How long together, given how long each takes alone."""
    a, b = ctx.rnd.choice([(4, 12), (6, 12), (3, 6), (10, 15), (8, 24), (5, 20)])
    from math import gcd
    num, den = a * b, a + b
    g = gcd(num, den)
    ans = f'{num // g}/{den // g}' if den // g != 1 else str(num // g)
    nm1, nm2 = ctx.two_names()
    return (f'{nm1} can paint a wall in {a} hours and {nm2} can paint it in {b} hours. '
            f'Working together, how many hours will it take?',
            ans, [str(a + b), str((a + b) // 2), str(abs(b - a))],
            'Think about how much of the wall each finishes in one hour.',
            f'In one hour they paint 1/{a} + 1/{b} of the wall. '
            f'Together they need {ans} hours.')

TEMPLATES = {k: v for k, v in list(globals().items()) if k.startswith('t_')}


# ════════════════════════════════════════════════════════════════════
def stable_id(board, subject, grade, stem):
    h = hashlib.sha1(stem.encode('utf-8')).hexdigest()[:8]
    return f'{board}-{subject}-G{grade}-{h}'.upper()


def build_question(ctx, topic):
    fn = TEMPLATES.get('t_' + topic)
    if not fn: return None
    made = fn(ctx)
    # A template that cannot find numbers giving an exact answer says so and
    # is asked again, rather than nudging its own inputs until they fit —
    # which is what produced a ₹450 answer to a ₹364.50 question.
    if not made: return None
    stem, ans, wrongs, hint, expl = made

    ans_s = str(ans)
    ans_v = value_of(ans_s)
    seen = {ans_s}
    opts = [ans_s]

    def usable(w):
        """A distractor has to be wrong. Not merely written differently —
           wrong. 5/10 next to 1/2 is a trap for the child who is right,
           and the checker caught eighty of them in the first build."""
        if w in seen: return False
        v = value_of(w)
        if ans_v is not None and v is not None and v == ans_v: return False
        return True

    for w in wrongs:
        w = str(w)
        if not usable(w): continue
        seen.add(w); opts.append(w)

    # top up if a mistake happened to land on the right answer
    k = 1
    while len(opts) < 4 and k < 40:
        if isinstance(ans, int):
            cand = str(ans + k if k % 2 else ans - k)
        elif ans_v is not None and ans_v.denominator > 1:
            cand = f'{ans_v.numerator + k}/{ans_v.denominator}'
        else:
            cand = re.sub(r'^(-?[\d.]+)', lambda m: str(float(m.group(1)) + k).rstrip('0').rstrip('.'), ans_s)
            if cand == ans_s: cand = f'{ans_s} +{k}'
        if usable(cand): seen.add(cand); opts.append(cand)
        k += 1
    opts = opts[:4]
    ctx.rnd.shuffle(opts)

    return {
        'id': stable_id(ctx.board, 'MATH', ctx.grade, stem),
        'question': stem,
        'options': opts,
        'answer': ans_s,
        'hint': hint,
        'explanation': expl,
        'topic': topic,
        'difficulty': ctx.difficulty,
        'grade': ctx.grade,
        'board': ctx.board,
        'subject': 'Math',
        'source': 'generated',
    }


def build_file(board, grade, per_difficulty=50):
    """One grade of one board. Seeded from the board and grade so the same
       file rebuilds identically — a question whose id survives but whose
       numbers change would quietly invalidate every stored answer."""
    rnd = random.Random(f'{board}|MATH|{grade}')
    topics = SYLLABUS[grade]
    out, seen_stems = [], set()
    for diff in ('easy', 'medium', 'hard'):
        ctx = Ctx(board, grade, diff, rnd)
        pool = topics
        if diff == 'hard' and grade in SYLLABUS_HARD:
            pool = SYLLABUS_HARD[grade]
        elif diff == 'medium' and grade in SYLLABUS_HARD:
            pool = topics + SYLLABUS_HARD[grade][:3]
        made, guard = 0, 0
        while made < per_difficulty and guard < per_difficulty * 60:
            guard += 1
            q = build_question(ctx, pool[guard % len(pool)])
            if not q: continue
            if q['question'] in seen_stems: continue     # no duplicate stems in a file
            if len(q['question'].split()) > MAX_WORDS[grade] + 8: continue
            seen_stems.add(q['question'])
            out.append(q); made += 1
    return out


def write_all(root='QUESTION_BANK', grades=range(1, 9), per_difficulty=50):
    made = {}
    for board in BOARDS:
        for grade in grades:
            qs = build_file(board, grade, per_difficulty)
            d = os.path.join(root, board, 'Math', f'Grade {grade}')
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, f'{board}_MATH_GRADE{grade}.JSON')
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({
                    'board': board, 'subject': 'Math', 'grade': grade,
                    'count': len(qs),
                    'note': 'Generated from parameterised templates; every answer is '
                            'computed from the same numbers the question is printed '
                            'from. Nothing here is copied from any past paper or '
                            'textbook.',
                    'questions': qs
                }, f, ensure_ascii=False, indent=1)
            made[path] = len(qs)
    return made


if __name__ == '__main__':
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else 'QUESTION_BANK'
    made = write_all(root)
    print(f'{len(made)} files, {sum(made.values())} questions')
