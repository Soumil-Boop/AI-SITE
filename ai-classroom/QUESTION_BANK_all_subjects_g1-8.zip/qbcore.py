# -*- coding: utf-8 -*-
"""The parts every subject needs, written once.

Maths could compute its own answers. Nothing else can — a science question
is only as right as the fact behind it — so for the other subjects the
guarantee has to move. It moves here, to the assembly: a question is built
from a curated item, and this module is what makes sure the item becomes a
fair question. Distractors that are secretly correct, options that repeat,
answers missing from their own option list, stems that appear twice in one
file: all of those are bugs this file exists to make impossible, whatever
subject is calling it.

The facts themselves are the author's problem, and the bank says so: every
non-maths question is marked `source: original` and `review: pending` until
a person has read it.
"""
import hashlib, json, os, re
from fractions import Fraction


def value_of(s):
    """The number a printed option represents, or None. Two options that read
       differently but mean the same number make a question that punishes a
       child who is right."""
    s = str(s).strip()
    s = re.sub(r'^[₹£$]', '', s)
    s = re.sub(r'\s*(cm|in|m|kg|g|km)?[²³]?\s*$', '', s)
    s = s.replace(',', '').replace('−', '-').replace('°', '')
    m = re.fullmatch(r'(-?\d+)\s*/\s*(\d+)', s)
    if m:
        try: return Fraction(int(m.group(1)), int(m.group(2)))
        except ZeroDivisionError: return None
    try: return Fraction(s)
    except Exception: return None


def norm(s):
    """For comparing two options as text: case and spacing should not be the
       difference between right and wrong."""
    return re.sub(r'\s+', ' ', str(s).strip().lower())


def stable_id(board, subject, grade, stem):
    h = hashlib.sha1(stem.encode('utf-8')).hexdigest()[:8]
    g = f'G{grade}' if grade else 'X'
    return f'{board}-{subject}-{g}-{h}'.upper()


def make(board, subject, grade, difficulty, topic, stem, answer, wrongs,
         hint, explanation, source='original', rnd=None, extra=None):
    """One question, assembled and checked as it is built.

       Returns None rather than a broken question when there are not enough
       genuinely wrong options to choose from — a three-option question, or
       one whose distractors are all secretly right, is worse than one fewer
       question."""
    ans_s = str(answer)
    ans_v = value_of(ans_s)
    seen = {norm(ans_s)}
    opts = [ans_s]

    for w in wrongs:
        w = str(w)
        if norm(w) in seen:
            continue
        v = value_of(w)
        if ans_v is not None and v is not None and v == ans_v:
            continue                      # equal in value, different in text
        seen.add(norm(w))
        opts.append(w)
        if len(opts) == 4:
            break

    if len(opts) < 4:
        return None

    if rnd: rnd.shuffle(opts)

    q = {
        'id': stable_id(board, subject, grade, stem),
        'question': stem,
        'options': opts,
        'answer': ans_s,
        'hint': hint,
        'explanation': explanation,
        'topic': topic,
        'difficulty': difficulty,
        'grade': grade,
        'board': board,
        'subject': subject,
        'source': source,
    }
    if source != 'generated':
        # Written by a person, so a person has to read it. Said in the data
        # rather than in a README nobody opens.
        q['review'] = 'pending'
    if extra: q.update(extra)
    return q


def write_file(root, board, subject, grade, questions, note):
    d = os.path.join(root, board, subject, f'Grade {grade}')
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f'{board}_{subject.upper()}_GRADE{grade}.JSON')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump({'board': board, 'subject': subject, 'grade': grade,
                   'count': len(questions), 'note': note,
                   'questions': questions}, f, ensure_ascii=False, indent=1)
    return path, len(questions)


def fill(rnd, pool_fn, target, seen_stems, cap_factor=80):
    """Draw from a generator until the target is met or the pool is dry.

       The cap is the honest part. When a subject's curated content cannot
       honestly fill a file, the file comes up short and the count says so —
       padding it to a round number with near-duplicates would make the bank
       look bigger and be worth less."""
    out, guard = [], 0
    while len(out) < target and guard < target * cap_factor:
        guard += 1
        q = pool_fn()
        if not q: continue
        if q['question'] in seen_stems: continue
        seen_stems.add(q['question'])
        out.append(q)
    return out
