# The question bank — layout and schema

## Where the files go

```
QUESTION_BANK/
  CBSE/
    Math/    Grade 1/CBSE_MATH_GRADE1.JSON  …  Grade 8/CBSE_MATH_GRADE8.JSON
    Science/ Grade 1/CBSE_SCIENCE_GRADE1.JSON …
    English/ Grade 1/CBSE_ENGLISH_GRADE1.JSON …
  ICSE/        (same three subjects, same eight grades)
  UK_NATIONAL/ (same)
  US_COMMON_CORE/ (same)
```

Four boards × three subjects × eight grades = 96 files. The names are
predictable on purpose: a file path can be built from a student's profile
without a lookup table, because `curriculum` and `grade` are already stored
on every account.

### Ready for what comes next

Two extensions were designed for rather than bolted on later.

**Grades 9–12** need a fourth level, because "Science, Grade 11" is really
Physics, Chemistry and Biology. The layout takes it without changing shape:

```
  CBSE/Science/Grade 11/Physics/CBSE_SCIENCE_PHYSICS_GRADE11.JSON
```

Anything reading the bank walks the directory rather than assuming a depth,
so a stream folder appearing does not break it.

**Government exams** are not graded, so they hang off the board level with a
paper name where a grade would be:

```
  GOVERNMENT/SSC_CGL/Reasoning/GOVERNMENT_SSC_CGL_REASONING.JSON
  GOVERNMENT/UPSC_PRELIMS/GK/GOVERNMENT_UPSC_PRELIMS_GK.JSON
```

The `grade` field becomes null and `paper` carries the exam name. Everything
else in a question is unchanged.

## One question

The five fields the site already uses are unchanged, so anything written
against `data/question-bank.json` keeps working:

```json
{
  "question": "What is 47 + 28?",
  "options": ["65", "75", "615", "75"],
  "answer": "75",
  "hint": "Add the ones first, then carry into the tens.",
  "explanation": "7 + 8 = 15, so write 5 and carry 1. 4 + 2 + 1 = 7. The answer is 75."
}
```

Everything below is added, and every one of them earns its place:

| field | why it exists |
|---|---|
| `id` | Stable across regenerations, so a student's history still points at a real question after the bank is rebuilt. Derived from board, subject, grade and a hash of the stem — not a counter, which would renumber everything the moment one question is inserted. |
| `topic` | The syllabus strand, e.g. `fractions`. What lets the Lab ask for practice on one thing. |
| `difficulty` | `easy`, `medium` or `hard`. Defined per grade, not absolutely — a hard Grade 2 question is not a medium Grade 5 one. |
| `grade` | 1–8 here; `null` for government papers. |
| `board` | `CBSE`, `ICSE`, `UK_NATIONAL`, `US_COMMON_CORE`, `GOVERNMENT`. |
| `subject` | `Math`, `Science`, `English`. |
| `source` | Where the question came from, and this is the important one. `generated` — built from a template with the answer computed. `original` — written for this bank. `imported` — taken from an openly licensed source, in which case `licence` and `attribution` are required and are not optional. |
| `licence` | Present only on imported questions. The licence the source is under. |
| `attribution` | Present only on imported questions. The credit the licence requires. |

## What `source` is for

It is not bookkeeping. Three kinds of question carry three different risks
and the file has to say which is which.

A `generated` question cannot be wrong about arithmetic, because the answer
was computed rather than typed — but it can be dull, and it can be aimed at
the wrong grade.

An `original` question can be wrong in the way any written thing can be
wrong, and needs a human to read it.

An `imported` question carries someone else's licence, and that licence
has conditions. Recording it per question rather than per file means a
question can never drift away from its terms — which is how attribution
gets lost.

## What is *not* in here

No question copied from a copyrighted past paper or textbook. CBSE and ICSE
material is copyright NCERT and the respective boards, and NCERT has issued
public warnings about exactly this. The CBSE and ICSE questions in this bank
are written against the published syllabus — a topic list is a fact and
carries no copyright — and are new.
