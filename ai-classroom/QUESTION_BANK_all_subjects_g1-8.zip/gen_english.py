# -*- coding: utf-8 -*-
"""English, built from rules and word lists rather than from a template
that pretends to be a rule.

English is the one non-maths subject where generation is honest, because
most of what is tested at these grades IS a rule: the plural of a word
ending in -ch, the past tense of a strong verb, whether it is a or an. The
answer can be derived rather than remembered, and where it cannot — an
opposite, a homophone — it comes from a curated pair, which is a fact one
person wrote down once and can be checked.

Spelling follows the board: British forms for CBSE, ICSE and the UK,
American for the US list, because marking a British child wrong for
'colour' is not an English test, it is a bug.
"""
import random
from qbcore import make, fill

# ── words, by how hard they are rather than by grade ────────────────
NOUNS = {
  'a': ['cat', 'dog', 'box', 'bus', 'cup', 'hat', 'pen', 'bag', 'star', 'tree',
        'book', 'door', 'fish', 'bird', 'ball', 'shoe', 'leaf', 'baby', 'chair',
        'apple', 'brush', 'glass', 'watch', 'dress', 'child', 'foot', 'tooth',
        'mouse', 'man', 'woman', 'sheep', 'knife', 'city', 'lady', 'story'],
  'b': ['bench', 'branch', 'library', 'country', 'family', 'journey', 'valley',
        'hero', 'potato', 'tomato', 'piano', 'photo', 'wolf', 'shelf', 'thief',
        'loaf', 'goose', 'ox', 'deer', 'aircraft', 'crisis', 'radius', 'cactus',
        'diary', 'factory', 'monkey', 'chimney', 'wife', 'life', 'half'],
}

IRREGULAR_PLURAL = {
  'child': 'children', 'foot': 'feet', 'tooth': 'teeth', 'mouse': 'mice',
  'man': 'men', 'woman': 'women', 'sheep': 'sheep', 'goose': 'geese',
  'ox': 'oxen', 'deer': 'deer', 'aircraft': 'aircraft', 'crisis': 'crises',
  'radius': 'radii', 'cactus': 'cacti', 'knife': 'knives', 'wolf': 'wolves',
  'shelf': 'shelves', 'thief': 'thieves', 'loaf': 'loaves', 'wife': 'wives',
  'life': 'lives', 'half': 'halves',
}

VERBS = {  # present : (past, past participle)
  'go': ('went', 'gone'), 'eat': ('ate', 'eaten'), 'see': ('saw', 'seen'),
  'run': ('ran', 'run'), 'write': ('wrote', 'written'), 'take': ('took', 'taken'),
  'give': ('gave', 'given'), 'come': ('came', 'come'), 'drink': ('drank', 'drunk'),
  'sing': ('sang', 'sung'), 'swim': ('swam', 'swum'), 'begin': ('began', 'begun'),
  'break': ('broke', 'broken'), 'choose': ('chose', 'chosen'), 'drive': ('drove', 'driven'),
  'fall': ('fell', 'fallen'), 'fly': ('flew', 'flown'), 'forget': ('forgot', 'forgotten'),
  'grow': ('grew', 'grown'), 'know': ('knew', 'known'), 'ride': ('rode', 'ridden'),
  'ring': ('rang', 'rung'), 'rise': ('rose', 'risen'), 'speak': ('spoke', 'spoken'),
  'steal': ('stole', 'stolen'), 'teach': ('taught', 'taught'), 'throw': ('threw', 'thrown'),
  'wear': ('wore', 'worn'), 'win': ('won', 'won'), 'buy': ('bought', 'bought'),
  'bring': ('brought', 'brought'), 'catch': ('caught', 'caught'), 'think': ('thought', 'thought'),
  'sleep': ('slept', 'slept'), 'leave': ('left', 'left'), 'make': ('made', 'made'),
  'find': ('found', 'found'), 'hold': ('held', 'held'), 'keep': ('kept', 'kept'),
  'build': ('built', 'built'),
}

OPPOSITES = [
  ('big', 'small'), ('hot', 'cold'), ('up', 'down'), ('day', 'night'),
  ('happy', 'sad'), ('fast', 'slow'), ('open', 'shut'), ('full', 'empty'),
  ('hard', 'soft'), ('light', 'dark'), ('near', 'far'), ('young', 'old'),
  ('early', 'late'), ('clean', 'dirty'), ('rich', 'poor'), ('wet', 'dry'),
  ('brave', 'afraid'), ('ancient', 'modern'), ('ascend', 'descend'),
  ('accept', 'refuse'), ('arrive', 'depart'), ('polite', 'rude'),
  ('generous', 'selfish'), ('victory', 'defeat'), ('permanent', 'temporary'),
  ('artificial', 'natural'), ('expand', 'shrink'), ('praise', 'blame'),
  ('sharp', 'blunt'), ('shallow', 'deep'), ('increase', 'decrease'),
  ('remember', 'forget'), ('question', 'answer'), ('friend', 'enemy'),
]

SYNONYMS = [
  ('big', 'large'), ('small', 'tiny'), ('happy', 'glad'), ('sad', 'unhappy'),
  ('quick', 'rapid'), ('begin', 'start'), ('end', 'finish'), ('shout', 'yell'),
  ('brave', 'courageous'), ('clever', 'intelligent'), ('difficult', 'hard'),
  ('quiet', 'silent'), ('strange', 'odd'), ('beautiful', 'lovely'),
  ('angry', 'furious'), ('tired', 'weary'), ('rich', 'wealthy'),
  ('famous', 'well-known'), ('important', 'significant'), ('help', 'assist'),
  ('reply', 'respond'), ('choose', 'select'), ('gather', 'collect'),
  ('ancient', 'old'), ('enormous', 'huge'), ('frighten', 'scare'),
]

HOMOPHONES = [
  ('their', 'there', "It is over ___, near the tree.", 'there'),
  ('to', 'too', "The soup is ___ hot to drink.", 'too'),
  ('its', "it's", "The dog wagged ___ tail.", 'its'),
  ('your', "you're", "___ going to enjoy this book.", "You're"),
  ('hear', 'here', "Can you ___ the music?", 'hear'),
  ('see', 'sea', "We swam in the ___.", 'sea'),
  ('write', 'right', "Please ___ your name at the top.", 'write'),
  ('flour', 'flower', "She picked a ___ from the garden.", 'flower'),
  ('peace', 'piece', "May I have a ___ of cake?", 'piece'),
  ('weather', 'whether', "The ___ was cold and wet.", 'weather'),
  ('break', 'brake', "Press the ___ to stop the car.", 'brake'),
  ('knight', 'night', "The ___ wore heavy armour.", 'knight'),
  ('plain', 'plane', "The ___ landed safely.", 'plane'),
  ('sun', 'son', "The ___ rose at six o'clock.", 'sun'),
  ('tail', 'tale', "Grandmother told us a ___ about a fox.", 'tale'),
  ('meet', 'meat', "Let us ___ at the library.", 'meet'),
]

COLLECTIVE = [
  ('a ___ of sheep', 'flock', ['herd', 'swarm', 'pack']),
  ('a ___ of cows', 'herd', ['flock', 'shoal', 'pride']),
  ('a ___ of bees', 'swarm', ['flock', 'herd', 'pack']),
  ('a ___ of fish', 'shoal', ['herd', 'swarm', 'pride']),
  ('a ___ of lions', 'pride', ['flock', 'shoal', 'herd']),
  ('a ___ of wolves', 'pack', ['pride', 'swarm', 'shoal']),
  ('a ___ of stars', 'galaxy', ['bunch', 'flock', 'pack']),
  ('a ___ of grapes', 'bunch', ['flock', 'pack', 'herd']),
  ('a ___ of soldiers', 'army', ['crew', 'gang', 'flock']),
  ('a ___ of sailors', 'crew', ['army', 'pride', 'herd']),
  ('a ___ of singers', 'choir', ['crew', 'army', 'pack']),
  ('a ___ of players', 'team', ['choir', 'swarm', 'shoal']),
]

PREPOSITION = [
  ('The book is ___ the table.', 'on', ['in', 'at', 'of']),
  ('She is good ___ mathematics.', 'at', ['on', 'in', 'for']),
  ('We arrived ___ Monday.', 'on', ['in', 'at', 'to']),
  ('He was born ___ July.', 'in', ['on', 'at', 'to']),
  ('The cat hid ___ the bed.', 'under', ['on', 'above', 'along']),
  ('I have been waiting ___ an hour.', 'for', ['since', 'from', 'by']),
  ('I have known her ___ 2019.', 'since', ['for', 'from', 'during']),
  ('Divide the sweets ___ the two of you.', 'between', ['among', 'across', 'along']),
  ('Divide the sweets ___ all six children.', 'among', ['between', 'across', 'beside']),
  ('The shop is ___ the corner.', 'around', ['inside', 'among', 'between']),
  ('She walked ___ the bridge.', 'across', ['among', 'between', 'beside']),
  ('Put your bag ___ the chair.', 'beside', ['among', 'between', 'across']),
]

PARTS = [
  ('run', 'verb'), ('beautiful', 'adjective'), ('quickly', 'adverb'),
  ('London', 'noun'), ('she', 'pronoun'), ('and', 'conjunction'),
  ('under', 'preposition'), ('happiness', 'noun'), ('bright', 'adjective'),
  ('softly', 'adverb'), ('they', 'pronoun'), ('because', 'conjunction'),
  ('jump', 'verb'), ('river', 'noun'), ('angry', 'adjective'),
  ('never', 'adverb'), ('but', 'conjunction'), ('write', 'verb'),
]

MISSPELT = [
  ('because', ['becuase', 'becouse', 'becasue']),
  ('beautiful', ['beautifull', 'beutiful', 'beautifil']),
  ('friend', ['freind', 'frend', 'friynd']),
  ('separate', ['seperate', 'saperate', 'separete']),
  ('necessary', ['neccessary', 'necesary', 'nesessary']),
  ('definitely', ['definately', 'definitly', 'defenitely']),
  ('receive', ['recieve', 'receve', 'reciev']),
  ('February', ['Febuary', 'Feburary', 'Februrary']),
  ('surprise', ['suprise', 'surprize', 'surpirse']),
  ('until', ['untill', 'untel', 'uintil']),
  ('address', ['adress', 'adres', 'addres']),
  ('business', ['buisness', 'bussiness', 'busines']),
  ('knowledge', ['knowlege', 'knowladge', 'knowledgde']),
  ('rhythm', ['rythm', 'rhythem', 'rhytm']),
]

IDIOMS = [
  ('a piece of cake', 'very easy', ['a real dessert', 'a small portion', 'a birthday party']),
  ('break the ice', 'make people feel at ease', ['damage something cold', 'end a friendship', 'go swimming']),
  ('once in a blue moon', 'very rarely', ['every month', 'at midnight', 'twice a year']),
  ('let the cat out of the bag', 'reveal a secret', ['free an animal', 'go shopping', 'make a mistake']),
  ('under the weather', 'feeling unwell', ['standing in rain', 'feeling cold', 'looking upward']),
  ('hit the books', 'study hard', ['throw a book', 'buy new books', 'stop reading']),
  ('a blessing in disguise', 'something good that seemed bad', ['a hidden gift', 'a costume', 'a secret prayer']),
  ('cost an arm and a leg', 'be very expensive', ['cause an injury', 'be free', 'be very heavy']),
]

US_SPELLING = {'colour': 'color', 'favourite': 'favorite', 'centre': 'center',
               'theatre': 'theater', 'travelling': 'traveling', 'practise': 'practice',
               'organise': 'organize', 'realise': 'realize', 'neighbour': 'neighbor',
               'honour': 'honor', 'labour': 'labor', 'metre': 'meter'}


def plural_of(w):
    """Derived from the rule, not looked up — which is the point: the rule
       is what is being taught, and the answer has to come from the same
       place the explanation does."""
    if w in IRREGULAR_PLURAL: return IRREGULAR_PLURAL[w], 'irregular'
    if w.endswith(('s', 'sh', 'ch', 'x', 'z')): return w + 'es', "add -es after s, sh, ch, x or z"
    if w.endswith('y') and w[-2] not in 'aeiou': return w[:-1] + 'ies', "change -y to -ies"
    if w.endswith('o') and w in ('hero', 'potato', 'tomato'): return w + 'es', "add -es"
    if w.endswith('o'): return w + 's', "add -s"
    return w + 's', "just add -s"


BANDS = {1: 'a', 2: 'a', 3: 'a', 4: 'b', 5: 'b', 6: 'b', 7: 'b', 8: 'b'}


def build(board, grade, rnd, difficulty):
    """One English question, drawn from whichever kind suits the grade."""
    band = BANDS[grade]
    kinds = ['plural', 'article', 'opposite', 'punct', 'partsofspeech', 'collective']
    if grade >= 2: kinds += ['tense', 'preposition']
    if grade >= 3: kinds += ['synonym', 'homophone', 'spelling']
    if grade >= 5: kinds += ['comparative', 'agreement']
    if grade >= 6: kinds += ['idiom', 'passive']
    kind = rnd.choice(kinds)
    us = board == 'US_COMMON_CORE'

    if kind == 'plural':
        w = rnd.choice(NOUNS[band] if band == 'a' else NOUNS['a'] + NOUNS['b'])
        p, why = plural_of(w)
        wrongs = [w + 's', w + 'es', w[:-1] + 'ies' if len(w) > 2 else w + 'ss']
        return make(board, 'English', grade, difficulty, 'plurals',
                    f'What is the plural of "{w}"?', p, wrongs,
                    'Look at the last letters of the word.',
                    f'The plural of "{w}" is "{p}" — {why}.', rnd=rnd)

    if kind == 'article':
        w = rnd.choice(NOUNS['a'] + NOUNS['b'])
        art = 'an' if w[0] in 'aeiou' else 'a'
        return make(board, 'English', grade, difficulty, 'articles',
                    f'Choose the correct article: ___ {w}', art,
                    ['an' if art == 'a' else 'a', 'the', 'some'],
                    'Listen to the first sound of the word.',
                    f'"{w}" begins with a {"vowel" if art == "an" else "consonant"} sound, so it takes "{art}".',
                    rnd=rnd)

    if kind == 'tense':
        v = rnd.choice(list(VERBS))
        past, pp = VERBS[v]
        if difficulty == 'hard' and grade >= 5:
            return make(board, 'English', grade, difficulty, 'tenses',
                        f'Complete the sentence: She has ___ the letter. (write: {v})', pp,
                        [past, v, v + 'ed'],
                        'After "has" or "have" you need the past participle.',
                        f'The past participle of "{v}" is "{pp}".', rnd=rnd)
        return make(board, 'English', grade, difficulty, 'tenses',
                    f'What is the past tense of "{v}"?', past,
                    [v + 'ed', pp if pp != past else v + 'd', v],
                    'Say the sentence "Yesterday I ..." in your head.',
                    f'The past tense of "{v}" is "{past}".', rnd=rnd)

    if kind in ('opposite', 'synonym'):
        pairs = OPPOSITES if kind == 'opposite' else SYNONYMS
        a, b = rnd.choice(pairs)
        if rnd.random() < .5: a, b = b, a
        others = [y for x, y in pairs if y != b and x != a]
        word = 'opposite' if kind == 'opposite' else 'closest in meaning'
        return make(board, 'English', grade, difficulty, kind + 's',
                    f'Which word is {word} to "{a}"?', b, rnd.sample(others, 3),
                    'Try each one in a sentence with the word.',
                    f'"{b}" is {word} to "{a}".', rnd=rnd)

    if kind == 'homophone':
        w1, w2, sent, right = rnd.choice(HOMOPHONES)
        wrong = w2 if right.lower() == w1.lower() else w1
        return make(board, 'English', grade, difficulty, 'homophones',
                    f'Choose the correct word: {sent}', right,
                    [wrong, wrong.capitalize() + 's', right + 's'],
                    'The two words sound the same but mean different things.',
                    f'"{right}" is the one that fits this sentence.', rnd=rnd)

    if kind == 'collective':
        stem, ans, wrongs = rnd.choice(COLLECTIVE)
        return make(board, 'English', grade, difficulty, 'collective nouns',
                    f'Complete: {stem}', ans, wrongs,
                    'Think of the word used for a group of them.',
                    f'The usual collective noun here is "{ans}".', rnd=rnd)

    if kind == 'preposition':
        stem, ans, wrongs = rnd.choice(PREPOSITION)
        return make(board, 'English', grade, difficulty, 'prepositions',
                    f'Choose the correct word: {stem}', ans, wrongs,
                    'Read the sentence aloud with each choice.',
                    f'"{ans}" is the preposition that fits here.', rnd=rnd)

    if kind == 'partsofspeech':
        w, p = rnd.choice(PARTS)
        others = list({x for _, x in PARTS if x != p})
        return make(board, 'English', grade, difficulty, 'parts of speech',
                    f'What part of speech is the word "{w}"?', p, rnd.sample(others, 3),
                    'Ask what the word is doing in a sentence.',
                    f'"{w}" is a {p}.', rnd=rnd)

    if kind == 'spelling':
        right, wrongs = rnd.choice(MISSPELT)
        if us and right in US_SPELLING: right = US_SPELLING[right]
        return make(board, 'English', grade, difficulty, 'spelling',
                    'Which word is spelled correctly?' if us else 'Which word is spelt correctly?',
                    right, wrongs, 'Sound it out in parts.',
                    f'The correct spelling is "{right}".', rnd=rnd)

    if kind == 'punct':
        name = rnd.choice(['ravi', 'sara', 'tom', 'anita', 'james', 'priya'])
        forms = [
            (f'{name.capitalize()} went to the market.', 'a full stop', ['a question mark', 'an exclamation mark', 'a comma']),
            (f'Where is {name.capitalize()} going?', 'a question mark', ['a full stop', 'a comma', 'a colon']),
            (f'What a beautiful day!', 'an exclamation mark', ['a full stop', 'a question mark', 'a semicolon']),
        ]
        sent, ans, wrongs = rnd.choice(forms)
        if us: ans = ans.replace('full stop', 'period'); wrongs = [w.replace('full stop', 'period') for w in wrongs]
        return make(board, 'English', grade, difficulty, 'punctuation',
                    f'Which punctuation mark ends this sentence? "{sent}"', ans, wrongs,
                    'Is it telling, asking or exclaiming?',
                    f'That sentence ends with {ans}.', rnd=rnd)

    if kind == 'comparative':
        adj = rnd.choice(['tall', 'big', 'happy', 'fast', 'clever', 'bright', 'small',
                          'heavy', 'early', 'strong'])
        if adj.endswith('y'): comp, sup = adj[:-1] + 'ier', adj[:-1] + 'iest'
        elif adj in ('big',): comp, sup = 'bigger', 'biggest'
        else: comp, sup = adj + 'er', adj + 'est'
        want_sup = rnd.random() < .5
        return make(board, 'English', grade, difficulty, 'comparatives',
                    f'What is the {"superlative" if want_sup else "comparative"} form of "{adj}"?',
                    sup if want_sup else comp,
                    [comp if want_sup else sup, 'more ' + adj, 'most ' + adj],
                    'Comparative compares two; superlative compares all.',
                    f'The {"superlative" if want_sup else "comparative"} of "{adj}" is "{sup if want_sup else comp}".',
                    rnd=rnd)

    if kind == 'agreement':
        subj, verb, wrong = rnd.choice([
            ('The dog', 'barks', 'bark'), ('The dogs', 'bark', 'barks'),
            ('She', 'writes', 'write'), ('They', 'write', 'writes'),
            ('Each of the boys', 'has', 'have'), ('The team', 'plays', 'play'),
            ('My friends', 'were', 'was'), ('Everyone', 'is', 'are'),
        ])
        return make(board, 'English', grade, difficulty, 'subject-verb agreement',
                    f'Choose the correct verb: {subj} ___ every day.', verb,
                    [wrong, verb + 'ed', 'are ' + verb],
                    'Is the subject one thing or more than one?',
                    f'"{subj}" takes "{verb}".', rnd=rnd)

    if kind == 'idiom':
        idiom, mean, wrongs = rnd.choice(IDIOMS)
        return make(board, 'English', grade, difficulty, 'idioms',
                    f'What does the idiom "{idiom}" mean?', mean, wrongs,
                    'An idiom does not mean what its words say.',
                    f'"{idiom}" means {mean}.', rnd=rnd)

    if kind == 'passive':
        act, pas = rnd.choice([
            ('The chef cooked the meal.', 'The meal was cooked by the chef.'),
            ('Rain soaked the field.', 'The field was soaked by the rain.'),
            ('The class read the poem.', 'The poem was read by the class.'),
            ('A dog chased the cat.', 'The cat was chased by a dog.'),
            ('Workers built the bridge.', 'The bridge was built by workers.'),
        ])
        wrongs = [pas.replace('was', 'is'), pas.replace(' by ', ' with '), act]
        return make(board, 'English', grade, difficulty, 'active and passive',
                    f'Change to the passive voice: "{act}"', pas, wrongs,
                    'The thing being acted on comes first in the passive.',
                    f'In the passive, "{act}" becomes "{pas}"', rnd=rnd)
    return None


def build_file(board, grade, per_difficulty=50):
    rnd = random.Random(f'{board}|ENGLISH|{grade}')
    seen, out = set(), []
    for diff in ('easy', 'medium', 'hard'):
        out += fill(rnd, lambda: build(board, grade, rnd, diff), per_difficulty, seen)
    return out
