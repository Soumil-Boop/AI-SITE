# -*- coding: utf-8 -*-
"""Build the whole bank into one folder.

Every board, every subject, grades 1–8, in the layout SCHEMA.md describes.
Maths keeps its own generator because it is the only subject whose answers
are computed; everything else comes through qbcore, which is what makes an
option list fair whatever wrote the item.
"""
import json, os, shutil, sys
import gen_math, gen_english, gen_facts
from qbcore import write_file

BOARDS = ['CBSE', 'ICSE', 'UK_NATIONAL', 'US_COMMON_CORE']
GRADES = range(1, 9)
FACT_SUBJECTS = ['Science', 'Social Studies', 'Computer Science', 'General Knowledge']

NOTE = {
 'Math': 'Generated from parameterised templates; every answer is computed from '
         'the same numbers the question is printed from, and re-derived '
         'independently by check_bank.py. Nothing is copied from any past paper '
         'or textbook.',
 'English': 'Built from spelling and grammar rules and from curated word lists. '
            'Rule-based answers are derived, not remembered. Nothing is copied '
            'from any past paper or textbook.',
 'other':  'Written for this bank from curated facts. Every question is marked '
           'review: pending until a person has read it. Nothing is copied from '
           'any past paper or textbook.',
}


def main(root='QUESTION_BANK', per=50, fresh=True):
    if fresh and os.path.isdir(root):
        shutil.rmtree(root)

    rows, totals = [], {}
    for board in BOARDS:
        for grade in GRADES:
            qs = gen_math.build_file(board, grade, per)
            p, n = write_file(root, board, 'Math', grade, qs, NOTE['Math'])
            rows.append((board, 'Math', grade, n)); totals['Math'] = totals.get('Math', 0) + n

            qs = gen_english.build_file(board, grade, per)
            p, n = write_file(root, board, 'English', grade, qs, NOTE['English'])
            rows.append((board, 'English', grade, n)); totals['English'] = totals.get('English', 0) + n

            for subj in FACT_SUBJECTS:
                qs = gen_facts.build_file(board, subj, grade, per)
                p, n = write_file(root, board, subj, grade, qs, NOTE['other'])
                rows.append((board, subj, grade, n)); totals[subj] = totals.get(subj, 0) + n

    # An index at the root, so anything reading the bank can see what is in
    # it without opening ninety-six files.
    index = {'boards': BOARDS, 'grades': list(GRADES),
             'subjects': ['Math', 'English'] + FACT_SUBJECTS,
             'totals': totals, 'total': sum(totals.values()),
             'files': [{'board': b, 'subject': s, 'grade': g, 'count': n}
                       for b, s, g, n in rows]}
    with open(os.path.join(root, 'INDEX.JSON'), 'w', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, indent=1)

    print(f'{len(rows)} files, {sum(totals.values())} questions')
    for s, n in sorted(totals.items(), key=lambda kv: -kv[1]):
        print(f'  {s:<20} {n:>6}')
    # Where a subject could not honestly fill a file, say so here rather
    # than letting a round number imply it did.
    short = [(b, s, g, n) for b, s, g, n in rows if n < per * 3]
    if short:
        print(f'\n{len(short)} file(s) came up short of {per*3}; the curated '
              f'content for those does not stretch further yet:')
        by_subject = {}
        for b, s, g, n in short: by_subject.setdefault(s, []).append(n)
        for s, ns in by_subject.items():
            print(f'  {s:<20} {len(ns)} file(s), {min(ns)}–{max(ns)} questions each')
    return index


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'QUESTION_BANK')
